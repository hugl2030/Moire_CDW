from __future__ import annotations

from os import PathLike
from typing import Any, Self

import numpy as np
from numpy.typing import NDArray
from scipy.ndimage import gaussian_filter, maximum_filter
from scipy.optimize import curve_fit
from scipy.spatial import cKDTree, KDTree

from quantem.core.datastructures.dataset2d import Dataset2d
from quantem.core.io.serialize import AutoSerialize
from quantem.core.utils.validators import ensure_valid_array
from quantem.core.visualization import show_2d


class DiffractionMoire(AutoSerialize):
    _token = object()

    def __init__(
        self,
        diffraction: Dataset2d,
        _token: object | None = None,
    ):
        if _token is not self._token:
            raise RuntimeError("Use DiffractionMoire.from_data() or .from_file() to instantiate this class.")
        self._diffraction = diffraction
        self.peaks = np.zeros((0, 2), dtype=float)

    @classmethod
    def from_file(
        cls,
        file_path: str | PathLike,
        file_type: str | None = None,
    ) -> Self:
        diffraction = Dataset2d.from_file(str(file_path), file_type=file_type)
        return cls.from_data(diffraction)

    @classmethod
    def from_data(
        cls,
        diffraction: Dataset2d | NDArray,
        *,
        name: str | None = None,
        origin: NDArray | float | int | None = None,
        sampling: NDArray | float | int | None = None,
        units: list[str] | None = None,
        signal_units: str = "arb. units",
    ) -> Self:
        if isinstance(diffraction, Dataset2d):
            ds = diffraction
            if name is not None:
                ds.name = name
        else:
            arr = ensure_valid_array(diffraction, ndim=2)
            ds = Dataset2d.from_array(
                arr,
                name=name if name is not None else "diffraction",
                origin=origin if origin is not None else np.zeros(2),
                sampling=sampling if sampling is not None else np.ones(2),
                units=units if units is not None else ["pixels"] * 2,
                signal_units=signal_units,
            )

        return cls(
            diffraction=ds,
            _token=cls._token,
        )

    @property
    def diffraction(self) -> Dataset2d:
        return self._diffraction
    
    def find_diffraction_center_robust(self, peaks, tolerance=3.0, max_iters=20000):
        """
        Robustly back-calculate diffraction center using RANSAC to ignore noise.
        """
        peaks = np.asarray(peaks, dtype=float)
        num_peaks = len(peaks)
        if num_peaks < 2:
            return np.mean(peaks, axis=0) if num_peaks > 0 else np.zeros(2)
            
        tree = cKDTree(peaks)
        
        best_center = np.mean(peaks, axis=0)
        max_inliers = -1

        for _ in range(max_iters):
            idx1, idx2 = np.random.choice(num_peaks, 2, replace=False)
            candidate_center = (peaks[idx1] + peaks[idx2]) / 2
            
            flipped = 2 * candidate_center - peaks
            dists, _ = tree.query(flipped, k=1)
            
            inliers = np.sum(dists < tolerance)
            
            if inliers > max_inliers:
                max_inliers = inliers
                best_center = candidate_center

        flipped_best = 2 * best_center - peaks
        dists, indices = tree.query(flipped_best, k=1)
        mask = dists < tolerance
        
        valid_pairs_midpoints = (peaks[mask] + peaks[indices[mask]]) / 2
        refined_center = np.mean(valid_pairs_midpoints, axis=0)

        print(f"Result: find {max_inliers} symmetric point pairs, final center: {refined_center}")
        return refined_center

    def find_peaks(
        self,
        *,
        threshold: float | None = None,
        min_distance_px: float | None = None,
        max_peaks: int | None = None,
        sigma_range: tuple[float, float] = (3.0, 1.0), # [新增] 定义扫描范围
        sigma_step: float = 0.1,
        mask_diffraction: NDArray | None = None,
        refine_subpixel: bool = True,
        refine_radius_px: int = 4,
        refine_maxfev: int = 500,
        plot_result: bool = True,
        plot_radius_min_px: float = 2.0,
        plot_radius_max_px: float = 10.0,
        plot_radius_power: float = 0.5,
        plot_edgecolor: str = "r",
        plot_linewidth: float = 1.0,
        plot_alpha: float = 0.5,
        plot_labels: bool = False,
        plot_label_color: Any = (0, 0.9, 1.0),
        plot_label_size: float = 6.0,
        plot_label_alpha: float = 0.9,
        plot_label_offset_px: tuple[float, float] = (0.0, -12.0),
        plot_label_bbox: bool = True,
        plot_label_bbox_facecolor: Any = (0.0, 0.0, 0.0, 0.35),
        plot_label_bbox_edgecolor: Any = "none",
        plot_label_bbox_pad: float = 0.15,
        plot_label_top_k: int | None = None,
        return_peaks: bool = False,
        **kwargs: Any,
    ) -> dict[str, Any]:
        im = np.asarray(self.diffraction.array)
        if im.ndim != 2:
            raise ValueError("DiffractionMoire.find_peaks requires a 2D diffraction array.")

        # --- [逻辑变更] 初始化结果容器 ---
        all_detected_peaks = np.zeros((0, 2), dtype=float)
        
        # --- [新增] Sigma 递减循环扫描 ---
        # 从 3.0 降到 1.0，步长 0.1
        sigmas = np.arange(sigma_range[0], sigma_range[1] - 1e-5, -sigma_step)
        
        for s in sigmas:
            im_s = gaussian_filter(im, sigma=float(s)) if float(s) > 0 else im

            # [逻辑变更] 阈值在每一层 sigma 下动态计算（如果未手动指定）
            if threshold is None:
                mu = float(np.nanmean(im_s))
                sig = float(np.nanstd(im_s))
                curr_threshold = mu + 5.0 * sig
            else:
                curr_threshold = float(threshold)

            # [逻辑变更] NMS 窗口大小随 min_distance_px 调整
            win = max(3, int(np.ceil(min_distance_px) * 2 + 1))
            mx = maximum_filter(im_s, size=win, mode="nearest")
            cand_mask = (im_s == mx) & (im_s >= curr_threshold)

            if mask_diffraction is not None:
                cand_mask &= np.asarray(mask_diffraction).astype(bool)

            new_peaks = np.argwhere(cand_mask).astype(float)

            if new_peaks.size == 0:
                continue

            # --- [新增] 空间合并逻辑 (去重) ---
            if all_detected_peaks.size == 0:
                all_detected_peaks = new_peaks
            else:
                from scipy.spatial import cKDTree
                tree = cKDTree(all_detected_peaks)
                # 查找新点到已有点集的最近距离
                dists, _ = tree.query(new_peaks, k=1)
                
                # 只有距离大于 min_distance_px 的点才被认为是“新点”
                # 这样做保证了：如果 sigma 变化导致原有的点偏移，我们会保留大 sigma 时的稳定坐标
                unique_mask = dists > min_distance_px
                if np.any(unique_mask):
                    all_detected_peaks = np.vstack([all_detected_peaks, new_peaks[unique_mask]])

        # --- [逻辑变更] 后置排序 ---
        # 此时得到的 peaks 是多层扫描后的合并结果
        # 按照原图中的强度进行重新排序
        peak_I = im[all_detected_peaks[:, 0].astype(int), all_detected_peaks[:, 1].astype(int)].astype(float)
        order = np.argsort(-peak_I)
        self.peaks = all_detected_peaks[order]
        self.I = peak_I[order]
        peaks_rc = self.peaks

        if max_peaks is not None and self.peaks.shape[0] > int(max_peaks):
            self.peaks = self.peaks[: int(max_peaks)]
            self.I = self.I[: int(max_peaks)]

        # 构建输出字典 (初始化)
        out = {
            "peaks": self.peaks,
            "I": self.I,
            "threshold": threshold, # 记录用户输入的阈值
            "sigma_range": sigma_range,
        }

        if refine_subpixel and peaks_rc.shape[0] > 0:
            r = int(refine_radius_px)
            if r < 1:
                raise ValueError("refine_radius_px must be >= 1.")

            def _gauss2d(coords: NDArray, A: float, row0: float, col0: float, s: float, c: float) -> NDArray:
                rr, cc = coords
                return A * np.exp(-((rr - row0) ** 2 + (cc - col0) ** 2) / (2.0 * s * s)) + c

            peaks_rc_ref = peaks_rc.copy()
            I_ref = peak_I.copy()
            fit_params = np.full((peaks_rc.shape[0], 5), np.nan, dtype=float)
            fit_success = np.zeros((peaks_rc.shape[0],), dtype=bool)

            for k in range(peaks_rc.shape[0]):
                row0_i = float(peaks_rc[k, 0])
                col0_i = float(peaks_rc[k, 1])
                row_i = int(np.round(row0_i))
                col_i = int(np.round(col0_i))

                r0 = max(0, row_i - r)
                r1 = min(im_s.shape[0], row_i + r + 1)
                c0 = max(0, col_i - r)
                c1 = min(im_s.shape[1], col_i + r + 1)
                if (r1 - r0) < 3 or (c1 - c0) < 3:
                    continue

                patch = im_s[r0:r1, c0:c1].astype(float, copy=False)
                rr, cc = np.mgrid[r0:r1, c0:c1]
                xdata = np.vstack([rr.ravel(), cc.ravel()])
                ydata = patch.ravel()

                c_init = float(np.median(ydata))
                A_init = float(np.max(ydata) - c_init)
                if not np.isfinite(A_init) or A_init <= 0:
                    continue
                s_init = max(0.75, float(r) / 2.0)

                row_min = float(r0)
                row_max = float(r1 - 1)
                col_min = float(c0)
                col_max = float(c1 - 1)

                p0 = (A_init, row0_i, col0_i, s_init, c_init)
                lb = (0.0, row_min, col_min, 0.5, float(np.min(ydata) - abs(A_init)))
                ub = (
                    float(np.inf),
                    row_max,
                    col_max,
                    float(max(0.75, 2.0 * r)),
                    float(np.max(ydata) + abs(A_init)),
                )

                try:
                    popt, _ = curve_fit(
                        _gauss2d,
                        xdata,
                        ydata,
                        p0=p0,
                        bounds=(lb, ub),
                        maxfev=int(refine_maxfev),
                    )
                except Exception:
                    continue

                A_fit, row_fit, col_fit, s_fit, c_fit = (
                    float(popt[0]),
                    float(popt[1]),
                    float(popt[2]),
                    float(popt[3]),
                    float(popt[4]),
                )
                if not (np.isfinite(row_fit) and np.isfinite(col_fit) and np.isfinite(s_fit) and s_fit > 0):
                    continue

                peaks_rc_ref[k, 0] = row_fit
                peaks_rc_ref[k, 1] = col_fit
                I_ref[k] = max(A_fit + c_fit, float(im[row_i, col_i]))
                fit_params[k, :] = np.array([A_fit, row_fit, col_fit, s_fit, c_fit], dtype=float)
                fit_success[k] = True

            order_ref = np.argsort(-I_ref)
            peaks_rc_ref = peaks_rc_ref[order_ref]
            I_ref = I_ref[order_ref]
            fit_params = fit_params[order_ref]
            fit_success = fit_success[order_ref]

            out["peaks_refined"] = peaks_rc_ref
            out["I_refined"] = I_ref
            out["gaussian_fit_params"] = fit_params
            out["gaussian_fit_success"] = fit_success
            out["refine_radius_px"] = int(refine_radius_px)

            self.peaks = peaks_rc_ref
            self.I = I_ref
            out["peaks"] = peaks_rc_ref
            out["I"] = I_ref

        if plot_result:
            from matplotlib.patches import Circle

            fig, ax = show_2d(im_s, **kwargs)
            ax0 = ax.flat[0] if hasattr(ax, "flat") else ax

            peaks_plot = np.asarray(out["peaks"], dtype=float)
            I_plot = np.asarray(out["I"], dtype=float)

            if peaks_plot.size:
                I_min = float(np.nanmin(I_plot)) if I_plot.size else 0.0
                I_max = float(np.nanmax(I_plot)) if I_plot.size else 1.0
                denom = I_max - I_min
                if not np.isfinite(denom) or denom <= 0:
                    t = np.ones_like(I_plot, dtype=float)
                else:
                    t = np.clip((I_plot - I_min) / denom, 0.0, 1.0)

                t = np.power(t, float(plot_radius_power))
                radii = float(plot_radius_min_px) + (float(plot_radius_max_px) - float(plot_radius_min_px)) * t

                for (row, col), rad in zip(peaks_plot, radii):
                    ax0.add_patch(
                        Circle(
                            (col, row),
                            radius=float(rad),
                            facecolor="none",
                            edgecolor=plot_edgecolor,
                            linewidth=float(plot_linewidth),
                            alpha=float(plot_alpha),
                        )
                    )

                if plot_labels:
                    dcol, drow = float(plot_label_offset_px[0]), float(plot_label_offset_px[1])
                    bbox_kw = None
                    if plot_label_bbox:
                        bbox_kw = dict(
                            boxstyle=f"round,pad={float(plot_label_bbox_pad)}",
                            facecolor=plot_label_bbox_facecolor,
                            edgecolor=plot_label_bbox_edgecolor,
                        )

                    nlab = peaks_plot.shape[0]
                    if plot_label_top_k is not None:
                        nlab = min(nlab, int(plot_label_top_k))

                    for idx in range(nlab):
                        row, col = float(peaks_plot[idx, 0]), float(peaks_plot[idx, 1])
                        ax0.text(
                            float(col + dcol),
                            float(row + drow),
                            str(idx),
                            color=plot_label_color,
                            fontsize=float(plot_label_size),
                            alpha=float(plot_label_alpha),
                            ha="center",
                            va="center",
                            bbox=bbox_kw,
                        )

            ax0.figure.canvas.draw_idle()

        if return_peaks:
            return out

    def real_peaks_intensity_range(
        self,
        distance = 4.0,
        sigma = 1,
        plot_result: bool = True,
        plot_radius_min_px: float = 2.0,
        plot_radius_max_px: float = 10.0,
        plot_radius_power: float = 0.5,
        plot_edgecolor: str = "r",
        plot_linewidth: float = 1.0,
        plot_alpha: float = 0.5,
        plot_labels: bool = False,
        plot_label_color: Any = (0, 0.9, 1.0),
        plot_label_size: float = 6.0,
        plot_label_alpha: float = 0.9,
        plot_label_offset_px: tuple[float, float] = (0.0, -12.0),
        plot_label_bbox: bool = True,
        plot_label_bbox_facecolor: Any = (0.0, 0.0, 0.0, 0.35),
        plot_label_bbox_edgecolor: Any = "none",
        plot_label_bbox_pad: float = 0.15,
        plot_label_top_k: int | None = None,
        return_peaks: bool = False,
        **kwargs: Any,
    ) -> dict[str, Any]:
        im = np.asarray(self.diffraction.array)
        im_s = gaussian_filter(im, sigma=float(sigma)) if float(sigma) > 0 else im
        peaks = np.asarray(self.peaks, dtype=float)
        
        H, W = im.shape
        I = []
        
        dist = int(np.ceil(distance if distance is not None else 4.0))
        if dist <= 0:
            raise ValueError("distance must be > 0.")
        
        for k in range(peaks.shape[0]):
 
            r = int(np.rint(peaks[k, 0]))
            c = int(np.rint(peaks[k, 1]))
        
            row0 = int(max(r - dist, 0))
            row1 = int(min(r + dist + 1, H))   
            col0 = int(max(c - dist, 0))
            col1 = int(min(c + dist + 1, W))
        
            patch = im[row0:row1, col0:col1]
            I.append(float(patch.max()))

        I_arr = np.asarray(I)
        order_ref = np.argsort(-I_arr)
        peaks_rc_ref = peaks[order_ref]
        I_ref = I_arr[order_ref]
        out: dict[str, Any] = {
            "peaks": peaks_rc_ref,
            "I": I_ref,
        }
        self.peaks = peaks_rc_ref
        self.I = I_ref

        if plot_result:
            from matplotlib.patches import Circle

            fig, ax = show_2d(im_s, **kwargs)
            ax0 = ax.flat[0] if hasattr(ax, "flat") else ax

            peaks_plot = np.asarray(out["peaks"], dtype=float)
            I_plot = np.asarray(out["I"], dtype=float)

            if peaks_plot.size:
                I_min = float(np.nanmin(I_plot)) if I_plot.size else 0.0
                I_max = float(np.nanmax(I_plot)) if I_plot.size else 1.0
                denom = I_max - I_min
                if not np.isfinite(denom) or denom <= 0:
                    t = np.ones_like(I_plot, dtype=float)
                else:
                    t = np.clip((I_plot - I_min) / denom, 0.0, 1.0)

                t = np.power(t, float(plot_radius_power))
                radii = float(plot_radius_min_px) + (float(plot_radius_max_px) - float(plot_radius_min_px)) * t

                for (row, col), rad in zip(peaks_plot, radii):
                    ax0.add_patch(
                        Circle(
                            (col, row),
                            radius=float(rad),
                            facecolor="none",
                            edgecolor=plot_edgecolor,
                            linewidth=float(plot_linewidth),
                            alpha=float(plot_alpha),
                        )
                    )

                if plot_labels:
                    dcol, drow = float(plot_label_offset_px[0]), float(plot_label_offset_px[1])
                    bbox_kw = None
                    if plot_label_bbox:
                        bbox_kw = dict(
                            boxstyle=f"round,pad={float(plot_label_bbox_pad)}",
                            facecolor=plot_label_bbox_facecolor,
                            edgecolor=plot_label_bbox_edgecolor,
                        )

                    nlab = peaks_plot.shape[0]
                    if plot_label_top_k is not None:
                        nlab = min(nlab, int(plot_label_top_k))

                    for idx in range(nlab):
                        row, col = float(peaks_plot[idx, 0]), float(peaks_plot[idx, 1])
                        ax0.text(
                            float(col + dcol),
                            float(row + drow),
                            str(idx),
                            color=plot_label_color,
                            fontsize=float(plot_label_size),
                            alpha=float(plot_label_alpha),
                            ha="center",
                            va="center",
                            bbox=bbox_kw,
                        )

            ax0.figure.canvas.draw_idle()

        if return_peaks:
            return out_1


    def auto_find_lattice_vectors(
        self,
        peaks_number: int = 150,
        num: int = 3,
    ) -> list:
        """
        Automatically identify up to `num` lattice-vector pairs.
    
        Notes
        -----
        This version keeps the original algorithm and selection logic as intact as possible.
        The main changes are:
        1. code cleanup / clearer structure
        2. small safe speedups (KDTree reuse + per-pair caching)
        3. a couple of defensive fixes to avoid accidental runtime errors
        """
        peaks = np.asarray(self.peaks, dtype=float)
        intensity = np.asarray(self.I, dtype=float)
        im = np.asarray(self.diffraction.array)
        nrow, ncol = int(im.shape[0]), int(im.shape[1])
    
        # --- 1) Locate center / origin peak ---
        true_center = self.find_diffraction_center_robust(peaks)
        dists_to_true = np.linalg.norm(peaks - true_center, axis=1)
    
        search_radius = 10.0
        mask_near = dists_to_true < search_radius
    
        if np.any(mask_near):
            near_indices = np.where(mask_near)[0]
            highest_i_sub_idx = np.argmax(intensity[near_indices])
            center_peak_index = near_indices[highest_i_sub_idx]
    
            # Keep original behavior: refine that peak to the robust center.
            peaks[center_peak_index] = true_center
            print(
                f"Physical peak found near center, index: {center_peak_index}. "
                "Coordinates refined to True_center."
            )
        else:
            peaks = np.vstack([peaks, true_center.reshape(1, 2)])
            intensity = np.append(intensity, 0.0)
            center_peak_index = len(peaks) - 1
            print(
                f"No physical peak found near center. Ideal center added at index: "
                f"{center_peak_index} with intensity 0."
            )
    
        origin = true_center
        max_radius = min(nrow, ncol) // 2
    
        # --- 2) Candidate generation ---
        def generate_combination(peaks_number, origin, filtered_peaks, filtered_intensity):
            # peaks_number is intentionally kept here to preserve the original signature/behavior.
            idx_range = np.arange(len(filtered_intensity))
            multiple_intensity = (idx_range + 1) * filtered_intensity
    
            aa, bb = np.meshgrid(idx_range, idx_range)
            combinations = np.vstack([bb.ravel(), aa.ravel()]).T  # all pairs
    
            p_a = filtered_peaks[combinations[:, 0]].astype(float, copy=False)
            p_b = filtered_peaks[combinations[:, 1]].astype(float, copy=False)
    
            vec_oa = p_a - origin
            vec_ob = p_b - origin
            dot_products = np.sum(vec_oa * vec_ob, axis=1)
    
            norms_oa = np.linalg.norm(vec_oa, axis=1)
            norms_ob = np.linalg.norm(vec_ob, axis=1)
            cos_thetas = np.clip(dot_products / (norms_oa * norms_ob + 1e-9), -1.0, 1.0)
            angles = np.degrees(np.arccos(cos_thetas))
    
            mask = (
                (angles >= 40)
                & (angles <= 140)
                & (norms_oa > 0)
                & (norms_ob > 0)
            )
    
            select_combinations = combinations[mask]
            return select_combinations, multiple_intensity
    
        # --- 3) Lattice point helpers ---
        def _default_max_tile(u, v) -> int:
            du = float(np.linalg.norm(u))
            dv = float(np.linalg.norm(v))
            dmin = min(du, dv) if (du > 0 and dv > 0) else max(du, dv)
            if not np.isfinite(dmin) or dmin <= 0:
                return 10
            diag = float(np.hypot(nrow, ncol))
            mt = int(np.ceil(diag / dmin)) + 2
            return int(np.clip(mt, 3, 200))
    
        def _tile_points_bounded(r0, u, v, mt):
            if mt == 0:
                return r0[None, :].copy()
    
            a = np.arange(-mt, mt + 1, dtype=float)
            b = np.arange(-mt, mt + 1, dtype=float)
            aa, bb = np.meshgrid(a, b, indexing="ij")
    
            pts = (
                r0[None, None, :]
                + aa[..., None] * u[None, None, :]
                + bb[..., None] * v[None, None, :]
            )
            pts = pts.reshape(-1, 2)
    
            keep = (
                (pts[:, 0] >= 0.0)
                & (pts[:, 0] <= (nrow - 1))
                & (pts[:, 1] >= 0.0)
                & (pts[:, 1] <= (ncol - 1))
            )
            return pts[keep]
    
        try:
            from scipy.spatial import cKDTree as _KDTree
        except Exception:
            from scipy.spatial import KDTree as _KDTree
    
        def generate_two_lattice_moire(
            r0,
            u1,
            v1,
            u2,
            v2,
            nrow,
            ncol,
            maxlen=250,
            r_excl=2.0,
            decimals=3,
        ):
            pts_moire = None
    
            def _disp_set(u, v, maxlen):
                dmin = float(min(np.linalg.norm(u), np.linalg.norm(v)))
                if not np.isfinite(dmin) or dmin <= 0:
                    raise ValueError("Invalid lattice vectors for moire generation.")
    
                mt = int(np.ceil(maxlen / dmin)) + 1
                mt = int(np.clip(mt, 1, 200))
                a = np.arange(-mt, mt + 1, dtype=float)
                b = np.arange(-mt, mt + 1, dtype=float)
                aa, bb = np.meshgrid(a, b, indexing="ij")
                aa = aa.ravel()
                bb = bb.ravel()
    
                disp = aa[:, None] * u[None, :] + bb[:, None] * v[None, :]
                dn = np.sqrt(np.sum(disp**2, axis=1))
                keep = dn <= maxlen + 1e-9
    
                aa = aa[keep]
                bb = bb[keep]
                disp = disp[keep]
                return disp, np.stack([aa, bb], axis=1)
    
            disp1, ab1 = _disp_set(u1, v1, maxlen)
            disp2, ab2 = _disp_set(u2, v2, maxlen)
    
            if disp1.size and disp2.size:
                n1 = int(disp1.shape[0])
                n2 = int(disp2.shape[0])
                if n1 * n2 > 2_000_000:
                    raise ValueError(
                        f"Moire candidate count too large (N1*N2={n1*n2}). "
                        "Reduce moire_parent_maxlen_px to limit the search space."
                    )
    
                pts = r0[None, None, :] + disp1[:, None, :] + disp2[None, :, :]
                pts = pts.reshape(-1, 2)
    
                keep_combo = ~(
                    ((ab1[:, 0] == 0) & (ab1[:, 1] == 0))[:, None]
                    | ((ab2[:, 0] == 0) & (ab2[:, 1] == 0))[None, :]
                ).ravel()
                pts = pts[keep_combo]
    
                keep_bounds = (
                    (pts[:, 0] >= 0.0)
                    & (pts[:, 0] <= (nrow - 1))
                    & (pts[:, 1] >= 0.0)
                    & (pts[:, 1] <= (ncol - 1))
                )
                pts = pts[keep_bounds]
    
                if pts.size:
                    pts = np.unique(np.round(pts, int(decimals)), axis=0)
    
                    if r_excl > 0:
                        parent_pts = np.vstack((r0[None, :] + disp1, r0[None, :] + disp2))
                        parent_keep = (
                            (parent_pts[:, 0] >= 0.0)
                            & (parent_pts[:, 0] <= (nrow - 1))
                            & (parent_pts[:, 1] >= 0.0)
                            & (parent_pts[:, 1] <= (ncol - 1))
                        )
                        parent_pts = parent_pts[parent_keep]
    
                        if parent_pts.size:
                            try:
                                tree = _KDTree(parent_pts)
                                try:
                                    d, _ = tree.query(pts, k=1, workers=-1)
                                except TypeError:
                                    d, _ = tree.query(pts, k=1)
                                pts = pts[d >= r_excl]
                            except Exception:
                                r2 = r_excl * r_excl
                                keep = np.ones(pts.shape[0], dtype=bool)
                                for i in range(pts.shape[0]):
                                    d2 = np.sum((parent_pts - pts[i]) ** 2, axis=1)
                                    if np.any(d2 < r2):
                                        keep[i] = False
                                pts = pts[keep]
    
                    pts_moire = pts if pts.size else None
    
            return pts_moire
    
        final_basis_results = []
        filtered_peaks = peaks
    
        # --- 4) Loop over mask radius and rank candidates ---
        for current_mask_r in range(50, max_radius, 10):
            final_basis_results = []
    
            dists = np.linalg.norm(peaks - origin, axis=1)
            keep_mask = dists >= current_mask_r
            keep_mask[center_peak_index] = True
    
            filtered_peaks = peaks[keep_mask]
            filtered_intensity = intensity[keep_mask]
            print(len(filtered_peaks))
    
            select_combinations, multiple_intensity = generate_combination(
                peaks_number,
                origin,
                filtered_peaks,
                filtered_intensity,
            )
    
            if select_combinations.size == 0:
                continue
    
            filtered_tree = _KDTree(filtered_peaks)
            pair_cache = {}
    
            def _find_nearby_peaks_fast(target_points, radius=2):
                results = []
                for pt in target_points:
                    indices = filtered_tree.query_ball_point(pt, r=radius)
                    if indices:
                        results.append(indices[0])
                    else:
                        results.append(False)
                return results
    
            def _find_index_in_peaks(u, v):
                key = (int(u), int(v))
                if key in pair_cache:
                    return pair_cache[key]
    
                u_k = filtered_peaks[u].astype(float, copy=False) - origin
                v_k = filtered_peaks[v].astype(float, copy=False) - origin
                mt = _default_max_tile(u_k, v_k)
                pts = _tile_points_bounded(origin, u_k, v_k, mt)
                index = _find_nearby_peaks_fast(pts, radius=2)
                unique_indices = [i for i in index if i is not False]
    
                pair_cache[key] = unique_indices
                return unique_indices
    
            total_intensity = np.empty(select_combinations.shape[0], dtype=float)
            for k, (u, v) in enumerate(select_combinations):
                unique_indices = _find_index_in_peaks(u, v)
                total_intensity[k] = np.sum(multiple_intensity[unique_indices])
    
            order_ref = np.argsort(-total_intensity)
            select_combinations_ref = select_combinations[order_ref]
    
            print(select_combinations_ref)
            print(len(select_combinations_ref))
    
            if select_combinations_ref.size == 0:
                continue
    
            u_1, v_1 = select_combinations_ref[0]
            final_basis_results.append([u_1, v_1])
    
            k_indices = _find_index_in_peaks(u_1, v_1)
            forbidden_indices = set(k_indices)
            forbidden_indices.discard(center_peak_index)
    
            mask = np.ones(len(select_combinations_ref), dtype=bool)
            for j, (u, v) in enumerate(select_combinations_ref):
                j_indices = _find_index_in_peaks(u, v)
                j_indices_no_center = [idx for idx in j_indices if idx != center_peak_index]
                if any(idx in forbidden_indices for idx in j_indices_no_center):
                    mask[j] = False
    
            select_combinations_ref = select_combinations_ref[mask]
            print(select_combinations_ref)
            print(len(select_combinations_ref))
    
            if select_combinations_ref.size > 0:
                u_k, v_k = select_combinations_ref[0]
                final_basis_results.append([u_k, v_k])
            else:
                continue
    
            k_indices = _find_index_in_peaks(
                final_basis_results[1][0],
                final_basis_results[1][1],
            )
            forbidden_indices = set(k_indices)
            forbidden_indices.discard(center_peak_index)
    
            mask = np.ones(len(select_combinations_ref), dtype=bool)
            for j, (u, v) in enumerate(select_combinations_ref):
                j_indices = _find_index_in_peaks(u, v)
                j_indices_no_center = [idx for idx in j_indices if idx != center_peak_index]
                if any(idx in forbidden_indices for idx in j_indices_no_center):
                    mask[j] = False
    
            select_combinations_ref = select_combinations_ref[mask]
            print(select_combinations_ref)
            print(len(select_combinations_ref))
    
            H, W = im.shape
            pts_moire = generate_two_lattice_moire(
                r0=true_center,
                u1=peaks[u_1].astype(float, copy=False) - origin,
                v1=peaks[v_1].astype(float, copy=False) - origin,
                u2=peaks[u_k].astype(float, copy=False) - origin,
                v2=peaks[v_k].astype(float, copy=False) - origin,
                nrow=H,
                ncol=W,
            )
    
            match_r = 4.0
            matched_idx = np.array([], dtype=int)
    
            if pts_moire is not None and np.size(pts_moire) > 0:
                fp = np.asarray(filtered_peaks, dtype=float)
                pm = np.asarray(pts_moire, dtype=float)
    
                try:
                    tree = _KDTree(pm)
                    neighbors = tree.query_ball_point(fp, r=match_r)
                    matched_idx = np.flatnonzero([len(n) > 0 for n in neighbors]).astype(int)
                except Exception:
                    d2 = np.sum((fp[:, None, :] - pm[None, :, :]) ** 2, axis=2)
                    matched_idx = np.flatnonzero(np.any(d2 <= match_r**2, axis=1)).astype(int)
    
            print("matched_idx:", matched_idx)
    
            if matched_idx.size > 0 and select_combinations_ref.size > 0:
                keep_mask = ~(
                    np.isin(select_combinations_ref[:, 0], matched_idx)
                    | np.isin(select_combinations_ref[:, 1], matched_idx)
                )
                select_combinations_ref = select_combinations_ref[keep_mask]
                print(select_combinations_ref)
                print(len(select_combinations_ref))
    
                total_intensity_ref = []
                for u, v in select_combinations_ref:
                    unique_indices = _find_index_in_peaks(u, v)
    
                    if len(unique_indices) == 0:
                        total_intensity_ref.append(0.0)
                        continue
    
                    ui = np.unique(np.asarray(unique_indices, dtype=int))
                    d = np.linalg.norm(filtered_peaks[ui] - origin, axis=1)
                    order = np.argsort(d)
                    ui6 = ui[order[:6]]
    
                    total_intensity_ref.append(float(np.sum(multiple_intensity[ui6])))
    
                total_intensity_ref = np.asarray(total_intensity_ref)
                order_ref = np.argsort(-total_intensity_ref)
                select_combinations_ref = select_combinations_ref[order_ref]
    
                if select_combinations_ref.size > 0:
                    u_3, v_3 = select_combinations_ref[0]
                    final_basis_results.append([u_3, v_3])
    
            if len(final_basis_results) >= num:
                break
    
        # --- 5) Return result ---
        results = [center_peak_index]
        for basis in final_basis_results[:num]:
            results.extend([basis[0], basis[1]])
    
        for i in range(len(results)):
            target_peak = filtered_peaks[results[i]]
            results[i] = np.where((peaks == target_peak).all(axis=1))[0]
    
        print(len(results))
        print(results)
        return results


    def three_lattice_vectors(
        self,
        ind_origin=None,
        ind_u1=None,
        ind_v1=None,
        ind_u2=None,
        ind_v2=None,
        ind_u3=None,
        ind_v3=None,
        max_tile=None,
        moire_draw: bool = False,
    
        # ✅ 选择画哪些 moiré
        draw_moire12: bool = True,
        draw_moire13: bool = True,
        draw_moire23: bool = True,
        draw_moire123: bool = False,
    
        # ✅ 是否画 moire(1-2-3) 的全体点（默认不画，只画 extra）
        draw_moire123_all: bool = False,
    
        # ✅ 颜色默认数字形式 (r,g,b)
        color_origin=(0.0, 1.0, 0.0),
        color_lattice1=(1.0, 0.0, 0.0),
        color_lattice2=(0.0, 0.8, 1.0),
        color_lattice3=(0.0, 1.0, 0.5),
    
        color_moire12=(1.0, 0.5, 0.0),
        color_moire13=(0.6, 0.0, 1.0),
        color_moire23=(0.2, 0.9, 0.2),
        color_moire123_all=(0.8, 0.0, 1.0),
        color_moire123_extra=(0.0, 0.0, 0.0),
    
        # ✅ 透明度/大小/线宽等
        alpha_lattice_pts=0.8,
        alpha_moire_pair=0.9,
        alpha_moire123_all=0.25,
        alpha_moire123_extra=0.95,
    
        s_origin=90,
        s_vec_tip=45,
        s_lattice_pts=22,
        s_moire_pair=14,
        s_moire123_all=10,
        s_moire123_extra=22,
    
        lw_vec=1.2,
    
        # 这些参数保留（兼容旧调用），但不再用于在线标注
        vec_label_fontsize=9,
        vec_label_box_alpha=0.6,
    
        moire_exclude_radius_px: float = 2.0,
        moire_parent_maxlen_px: float | None = None,
        moire_round_decimals: int = 3,
        return_peaks: bool = False,
        **kwargs,
    ) -> dict[str, Any]:
    
        if not hasattr(self, "peaks"):
            raise RuntimeError("No peaks found. Run .find_peaks() first.")
        peaks = np.asarray(self.peaks, dtype=float)
        if peaks.ndim != 2 or peaks.shape[1] != 2:
            raise RuntimeError("self.peaks must have shape (N, 2) with columns [row, col].")
        if peaks.shape[0] == 0:
            raise RuntimeError("No peaks available in self.peaks.")
    
        im = np.asarray(self.diffraction.array)
        if im.ndim != 2:
            raise ValueError("DiffractionMoire.lattice_vectors requires a 2D diffraction array.")
        nrow, ncol = int(im.shape[0]), int(im.shape[1])
    
        def _as_int(x, name: str) -> int:
            if x is None:
                raise ValueError(f"{name} must be provided (int index into self.peaks).")
            xi = int(x)
            if xi < 0 or xi >= peaks.shape[0]:
                raise IndexError(f"{name}={xi} out of range for self.peaks with N={peaks.shape[0]}.")
            return xi
    
        def _pair_ok(a, b) -> bool:
            return (a is not None) and (b is not None)
    
        def _pair_half(a, b) -> bool:
            return (a is None) ^ (b is None)
    
        if _pair_half(ind_u1, ind_v1):
            raise ValueError("Provide both ind_u1 and ind_v1, or neither.")
        if _pair_half(ind_u2, ind_v2):
            raise ValueError("Provide both ind_u2 and ind_v2, or neither.")
        if _pair_half(ind_u3, ind_v3):
            raise ValueError("Provide both ind_u3 and ind_v3, or neither.")
    
        have_lattice1 = _pair_ok(ind_u1, ind_v1)
        have_lattice2 = _pair_ok(ind_u2, ind_v2)
        have_lattice3 = _pair_ok(ind_u3, ind_v3)
    
        if not (have_lattice1 or have_lattice2 or have_lattice3):
            raise ValueError("Provide lattice indices for at least one lattice (u/v).")
    
        if moire_draw and (int(have_lattice1) + int(have_lattice2) + int(have_lattice3) < 2):
            raise ValueError("moire_draw=True requires at least two lattices.")
    
        ind_origin_i = _as_int(ind_origin, "ind_origin")
        r0 = peaks[ind_origin_i].astype(float, copy=False)
    
        # --- vectors ---
        if have_lattice1:
            ind_u1_i = _as_int(ind_u1, "ind_u1")
            ind_v1_i = _as_int(ind_v1, "ind_v1")
            u1 = peaks[ind_u1_i].astype(float, copy=False) - r0
            v1 = peaks[ind_v1_i].astype(float, copy=False) - r0
        else:
            ind_u1_i = ind_v1_i = None
            u1 = v1 = None
    
        if have_lattice2:
            ind_u2_i = _as_int(ind_u2, "ind_u2")
            ind_v2_i = _as_int(ind_v2, "ind_v2")
            u2 = peaks[ind_u2_i].astype(float, copy=False) - r0
            v2 = peaks[ind_v2_i].astype(float, copy=False) - r0
        else:
            ind_u2_i = ind_v2_i = None
            u2 = v2 = None
    
        if have_lattice3:
            ind_u3_i = _as_int(ind_u3, "ind_u3")
            ind_v3_i = _as_int(ind_v3, "ind_v3")
            u3 = peaks[ind_u3_i].astype(float, copy=False) - r0
            v3 = peaks[ind_v3_i].astype(float, copy=False) - r0
        else:
            ind_u3_i = ind_v3_i = None
            u3 = v3 = None
    
        def _default_max_tile(u: np.ndarray, v: np.ndarray) -> int:
            du = float(np.linalg.norm(u))
            dv = float(np.linalg.norm(v))
            dmin = min(du, dv) if (du > 0 and dv > 0) else max(du, dv)
            if not np.isfinite(dmin) or dmin <= 0:
                return 10
            diag = float(np.hypot(nrow, ncol))
            mt = int(np.ceil(diag / dmin)) + 2
            return int(np.clip(mt, 3, 200))
    
        if max_tile is None:
            mt_list: list[int] = []
            if have_lattice1: mt_list.append(_default_max_tile(u1, v1))
            if have_lattice2: mt_list.append(_default_max_tile(u2, v2))
            if have_lattice3: mt_list.append(_default_max_tile(u3, v3))
            max_tile_use = max(mt_list) if mt_list else 10
        else:
            max_tile_use = int(max_tile)
    
        def _tile_points_bounded(r0: np.ndarray, u: np.ndarray, v: np.ndarray, mt: int) -> np.ndarray:
            if mt == 0:
                return r0[None, :].copy()
            a = np.arange(-mt, mt + 1, dtype=float)
            aa, bb = np.meshgrid(a, a, indexing="ij")
            pts = r0[None, None, :] + aa[..., None] * u[None, None, :] + bb[..., None] * v[None, None, :]
            pts = pts.reshape(-1, 2)
            keep = (
                (pts[:, 0] >= 0.0) & (pts[:, 0] <= (nrow - 1)) &
                (pts[:, 1] >= 0.0) & (pts[:, 1] <= (ncol - 1))
            )
            return pts[keep]
    
        pts1 = _tile_points_bounded(r0, u1, v1, max_tile_use) if have_lattice1 else None
        pts2 = _tile_points_bounded(r0, u2, v2, max_tile_use) if have_lattice2 else None
        pts3 = _tile_points_bounded(r0, u3, v3, max_tile_use) if have_lattice3 else None
    
        # === moiré sets ===
        pts_moire_12 = None
        pts_moire_13 = None
        pts_moire_23 = None
        pts_moire_123 = None
        pts_moire_123_extra = None
    
        if moire_draw:
            maxlen = float(moire_parent_maxlen_px) if moire_parent_maxlen_px is not None else float(0.5 * np.hypot(nrow, ncol))
    
            def _disp_set(u, v, maxlen):
                if u is None or v is None:
                    return np.zeros((0, 2), dtype=float), np.zeros((0, 2), dtype=float)
                u = np.asarray(u, dtype=float).reshape(-1)
                v = np.asarray(v, dtype=float).reshape(-1)
                if u.size != 2 or v.size != 2:
                    raise ValueError(f"u,v must be 2-vectors. got u.shape={u.shape}, v.shape={v.shape}")
    
                dmin = float(min(np.linalg.norm(u), np.linalg.norm(v)))
                if not np.isfinite(dmin) or dmin <= 0:
                    return np.zeros((0, 2), dtype=float), np.zeros((0, 2), dtype=float)
    
                mt = int(np.clip(np.ceil(maxlen / dmin) + 1, 1, 100))
                a = np.arange(-mt, mt + 1, dtype=float)
                aa, bb = np.meshgrid(a, a, indexing="ij")
                aa, bb = aa.ravel(), bb.ravel()
                disp = aa[:, None] * u[None, :] + bb[:, None] * v[None, :]
                keep = np.linalg.norm(disp, axis=1) <= maxlen + 1e-9
                return disp[keep], np.stack([aa[keep], bb[keep]], axis=1)
    
            def _bounds_filter(pts):
                if pts is None or pts.size == 0:
                    return None
                keep = (
                    (pts[:, 0] >= 0.0) & (pts[:, 0] <= (nrow - 1)) &
                    (pts[:, 1] >= 0.0) & (pts[:, 1] <= (ncol - 1))
                )
                pts = pts[keep]
                return pts if pts.size else None
    
            def _unique_round(pts):
                if pts is None or pts.size == 0:
                    return None
                pts = np.unique(np.round(pts, int(moire_round_decimals)), axis=0)
                return pts if pts.size else None
    
            def _exclude_parent(pts, parent_pts, r_excl):
                if pts is None or pts.size == 0:
                    return None
                r_excl = float(r_excl)
                if r_excl <= 0:
                    return pts
    
                parent_pts = np.asarray(parent_pts, dtype=float)
                if parent_pts.size == 0:
                    return pts
                keep = (
                    (parent_pts[:, 0] >= 0.0) & (parent_pts[:, 0] <= (nrow - 1)) &
                    (parent_pts[:, 1] >= 0.0) & (parent_pts[:, 1] <= (ncol - 1))
                )
                parent_pts = parent_pts[keep]
                if parent_pts.size == 0:
                    return pts
    
                from scipy.spatial import cKDTree
                tree = cKDTree(parent_pts)
                d, _ = tree.query(pts, k=1, workers=-1)
                pts = pts[d >= r_excl]
                return pts if pts.size else None
    
            def _moire_two(dA, abA, dB, abB, r_excl):
                if dA.size == 0 or dB.size == 0:
                    return None
                nA, nB = int(dA.shape[0]), int(dB.shape[0])
                if nA * nB > 2_000_000:
                    raise ValueError(f"Moire two-lattice candidates too large: {nA*nB}")
    
                pts = r0[None, None, :] + dA[:, None, :] + dB[None, :, :]
                pts = pts.reshape(-1, 2)
    
                zA = (abA[:, 0] == 0) & (abA[:, 1] == 0)
                zB = (abB[:, 0] == 0) & (abB[:, 1] == 0)
                keep_combo = ~(zA[:, None] | zB[None, :]).ravel()
                pts = pts[keep_combo]
    
                pts = _bounds_filter(pts)
                pts = _unique_round(pts)
                if pts is None:
                    return None
    
                parent_pts = np.vstack((r0[None, :] + dA, r0[None, :] + dB))
                pts = _exclude_parent(pts, parent_pts, r_excl)
                return pts
    
            def _moire_three(d1, ab1, d2, ab2, d3, ab3, r_excl):
                if d1.size == 0 or d2.size == 0 or d3.size == 0:
                    return None
                n1, n2, n3 = int(d1.shape[0]), int(d2.shape[0]), int(d3.shape[0])
                if n1 * n2 * n3 > 2_000_000:
                    raise ValueError(f"Moire three-lattice candidates too large: {n1*n2*n3}")
    
                pts = r0[None, None, None, :] + d1[:, None, None, :] + d2[None, :, None, :] + d3[None, None, :, :]
                pts = pts.reshape(-1, 2)
    
                z1 = (ab1[:, 0] == 0) & (ab1[:, 1] == 0)
                z2 = (ab2[:, 0] == 0) & (ab2[:, 1] == 0)
                z3 = (ab3[:, 0] == 0) & (ab3[:, 1] == 0)
                is_parent = (
                    (z1[:, None, None] & z2[None, :, None]) |
                    (z1[:, None, None] & z3[None, None, :]) |
                    (z2[None, :, None] & z3[None, None, :])
                ).ravel()
                pts = pts[~is_parent]
    
                pts = _bounds_filter(pts)
                pts = _unique_round(pts)
                if pts is None:
                    return None
    
                parent_pts = np.vstack((r0[None, :] + d1, r0[None, :] + d2, r0[None, :] + d3))
                pts = _exclude_parent(pts, parent_pts, r_excl)
                return pts
    
            def _pts_key(pts):
                pr = np.ascontiguousarray(np.round(pts, int(moire_round_decimals)))
                return pr.view(np.dtype((np.void, pr.dtype.itemsize * pr.shape[1]))).ravel()
    
            need_d1 = have_lattice1 and (draw_moire12 or draw_moire13 or draw_moire123)
            need_d2 = have_lattice2 and (draw_moire12 or draw_moire23 or draw_moire123)
            need_d3 = have_lattice3 and (draw_moire13 or draw_moire23 or draw_moire123)
    
            d1, ab1 = _disp_set(u1, v1, maxlen) if need_d1 else (np.zeros((0, 2)), np.zeros((0, 2)))
            d2, ab2 = _disp_set(u2, v2, maxlen) if need_d2 else (np.zeros((0, 2)), np.zeros((0, 2)))
            d3, ab3 = _disp_set(u3, v3, maxlen) if need_d3 else (np.zeros((0, 2)), np.zeros((0, 2)))
    
            if draw_moire12 and have_lattice1 and have_lattice2:
                pts_moire_12 = _moire_two(d1, ab1, d2, ab2, moire_exclude_radius_px)
            if draw_moire13 and have_lattice1 and have_lattice3:
                pts_moire_13 = _moire_two(d1, ab1, d3, ab3, moire_exclude_radius_px)
            if draw_moire23 and have_lattice2 and have_lattice3:
                pts_moire_23 = _moire_two(d2, ab2, d3, ab3, moire_exclude_radius_px)
    
            if draw_moire123 and have_lattice1 and have_lattice2 and have_lattice3:
                pts_moire_123 = _moire_three(d1, ab1, d2, ab2, d3, ab3, moire_exclude_radius_px)
    
                pair_list = [p for p in (pts_moire_12, pts_moire_13, pts_moire_23) if p is not None and p.size]
                if pts_moire_123 is not None and pts_moire_123.size:
                    if pair_list:
                        pair_all = np.unique(np.vstack(pair_list), axis=0)
                        k_pair = _pts_key(pair_all)
                        k_123 = _pts_key(pts_moire_123)
                        extra_mask = ~np.isin(k_123, k_pair)
                        pts_moire_123_extra = pts_moire_123[extra_mask] if np.any(extra_mask) else None
                    else:
                        pts_moire_123_extra = pts_moire_123
    
        data: dict[str, Any] = {
            "origin_index": ind_origin_i,
            "origin_rc": r0.copy(),
            "max_tile": max_tile_use,
            "lattice1_points_rc": pts1,
            "lattice2_points_rc": pts2,
            "lattice3_points_rc": pts3,
            "moire12_points_rc": pts_moire_12,
            "moire13_points_rc": pts_moire_13,
            "moire23_points_rc": pts_moire_23,
            "moire123_points_rc": pts_moire_123,
            "moire123_extra_points_rc": pts_moire_123_extra,
            "moire_points_rc": pts_moire_123,
        }
    
        if have_lattice1:
            data.update({"u1_index": ind_u1_i, "v1_index": ind_v1_i, "u1_rc": u1, "v1_rc": v1})
        if have_lattice2:
            data.update({"u2_index": ind_u2_i, "v2_index": ind_v2_i, "u2_rc": u2, "v2_rc": v2})
        if have_lattice3:
            data.update({"u3_index": ind_u3_i, "v3_index": ind_v3_i, "u3_rc": u3, "v3_rc": v3})
    
        self.lattice_vectors_data = data
    
        fig, ax = show_2d(im, **kwargs)
        ax0 = ax.flat[0] if hasattr(ax, "flat") else ax
    
        ax0.scatter([r0[1]], [r0[0]], s=s_origin, marker="x", c=[color_origin], linewidths=lw_vec, zorder=10)
    
        # ✅ 不再在线上标注 u1/v1/u2/v2/u3/v3
        def _draw_vec(vec, color):
            p = r0 + vec
            ax0.plot([r0[1], p[1]], [r0[0], p[0]], color=color, linewidth=lw_vec, zorder=9)
            ax0.scatter([p[1]], [p[0]], s=s_vec_tip, marker="o",
                        facecolors="none", edgecolors=[color], linewidths=lw_vec, zorder=10)
    
        if have_lattice1 and pts1 is not None and pts1.size:
            _draw_vec(u1, color_lattice1); _draw_vec(v1, color_lattice1)
            ax0.scatter(pts1[:, 1], pts1[:, 0], s=s_lattice_pts, marker="o",
                        facecolors="none", edgecolors=[color_lattice1],
                        alpha=alpha_lattice_pts, zorder=5, label="lattice1")
    
        if have_lattice2 and pts2 is not None and pts2.size:
            _draw_vec(u2, color_lattice2); _draw_vec(v2, color_lattice2)
            ax0.scatter(pts2[:, 1], pts2[:, 0], s=s_lattice_pts, marker="o",
                        facecolors="none", edgecolors=[color_lattice2],
                        alpha=alpha_lattice_pts, zorder=5, label="lattice2")
    
        if have_lattice3 and pts3 is not None and pts3.size:
            _draw_vec(u3, color_lattice3); _draw_vec(v3, color_lattice3)
            ax0.scatter(pts3[:, 1], pts3[:, 0], s=s_lattice_pts, marker="o",
                        facecolors="none", edgecolors=[color_lattice3],
                        alpha=alpha_lattice_pts, zorder=5, label="lattice3")
    
        n12 = n13 = n23 = n123 = nX = 0
    
        if pts_moire_12 is not None and pts_moire_12.size:
            ax0.scatter(pts_moire_12[:, 1], pts_moire_12[:, 0], s=s_moire_pair, marker="o",
                        facecolors="none", edgecolors=[color_moire12],
                        alpha=alpha_moire_pair, zorder=6, label="moire(1-2)")
            n12 = pts_moire_12.shape[0]
    
        if pts_moire_13 is not None and pts_moire_13.size:
            ax0.scatter(pts_moire_13[:, 1], pts_moire_13[:, 0], s=s_moire_pair, marker="o",
                        facecolors="none", edgecolors=[color_moire13],
                        alpha=alpha_moire_pair, zorder=6, label="moire(1-3)")
            n13 = pts_moire_13.shape[0]
    
        if pts_moire_23 is not None and pts_moire_23.size:
            ax0.scatter(pts_moire_23[:, 1], pts_moire_23[:, 0], s=s_moire_pair, marker="o",
                        facecolors="none", edgecolors=[color_moire23],
                        alpha=alpha_moire_pair, zorder=6, label="moire(2-3)")
            n23 = pts_moire_23.shape[0]
    
        if (pts_moire_123 is not None) and pts_moire_123.size:
            n123 = pts_moire_123.shape[0]
            if draw_moire123_all:
                ax0.scatter(pts_moire_123[:, 1], pts_moire_123[:, 0], s=s_moire123_all, marker=".",
                            c=[color_moire123_all], alpha=alpha_moire123_all, zorder=4,
                            label="moire(1-2-3) all")
    
        if pts_moire_123_extra is not None and pts_moire_123_extra.size:
            ax0.scatter(pts_moire_123_extra[:, 1], pts_moire_123_extra[:, 0], s=s_moire123_extra, marker="x",
                        c=[color_moire123_extra], alpha=alpha_moire123_extra, zorder=7,
                        label="moire(1-2-3) extra")
            nX = pts_moire_123_extra.shape[0]
    
        handles, labels = ax0.get_legend_handles_labels()
        if labels:
            ax0.legend(loc="upper right", fontsize=9, frameon=True)
    
        info = f"moire12={n12}, moire13={n13}, moire23={n23}, moire123={n123}, extra={nX}"
        ax0.text(
            0.01, 0.99, info,
            transform=ax0.transAxes,
            va="top", ha="left",
            fontsize=9,
            bbox=dict(facecolor="white", alpha=0.6, edgecolor="none"),
            zorder=20,
        )
    
        ax0.figure.canvas.draw_idle()
        return {"data": data, "fig": fig, "ax": ax0} if return_peaks else {}
    
