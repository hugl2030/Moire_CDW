from __future__ import annotations

from os import PathLike
from typing import Any, Literal, Self

import numpy as np
from numpy.typing import NDArray
from scipy.ndimage import gaussian_filter, maximum_filter
from scipy.optimize import curve_fit
from scipy.spatial import cKDTree

from quantem.core.datastructures.dataset2d import Dataset2d
from quantem.core.io.serialize import AutoSerialize
from quantem.core.utils.validators import ensure_valid_array
from quantem.core.visualization import show_2d

ArrayLike2D = NDArray[np.floating[Any]]
PeakArray = NDArray[np.float64]


class DiffractionMoire(AutoSerialize):
    """Utilities for peak finding and 1/2/3-lattice construction from 2D diffraction data."""

    _token = object()

    def __init__(
        self,
        diffraction: Dataset2d,
        _token: object | None = None,
    ):
        if _token is not self._token:
            raise RuntimeError(
                "Use DiffractionMoire.from_data() or .from_file() to instantiate this class."
            )
        self._diffraction = diffraction
        self.peaks: PeakArray = np.zeros((0, 2), dtype=float)
        self.I: NDArray[np.float64] = np.zeros((0,), dtype=float)
        self.lattice_vectors_data: dict[str, Any] = {}

    @classmethod
    def from_file(
        cls,
        file_path: str | PathLike,
        file_type: str | None = None,
    ) -> Self:
        diffraction = Dataset2d.from_file(str(file_path), file_type=file_type)
        return cls.from_data(diffraction)

    @classmethod
    def from_data(
        cls,
        diffraction: Dataset2d | NDArray[Any],
        *,
        name: str | None = None,
        origin: NDArray[Any] | float | int | None = None,
        sampling: NDArray[Any] | float | int | None = None,
        units: list[str] | None = None,
        signal_units: str = "arb. units",
    ) -> Self:
        if isinstance(diffraction, Dataset2d):
            ds = diffraction
            if name is not None:
                ds.name = name
        else:
            arr = ensure_valid_array(diffraction, ndim=2)
            ds = Dataset2d.from_array(
                arr,
                name=name if name is not None else "diffraction",
                origin=origin if origin is not None else np.zeros(2),
                sampling=sampling if sampling is not None else np.ones(2),
                units=units if units is not None else ["pixels"] * 2,
                signal_units=signal_units,
            )

        return cls(diffraction=ds, _token=cls._token)

    @property
    def diffraction(self) -> Dataset2d:
        return self._diffraction

    def _get_diffraction_array(self) -> NDArray[np.float64]:
        im = np.asarray(self.diffraction.array, dtype=float)
        if im.ndim != 2:
            raise ValueError("DiffractionMoire requires a 2D diffraction array.")
        return im

    @staticmethod
    def _normalize_peak_radii(
        intensities: NDArray[np.float64],
        radius_min: float,
        radius_max: float,
        power: float,
    ) -> NDArray[np.float64]:
        if intensities.size == 0:
            return np.zeros((0,), dtype=float)

        i_min = float(np.nanmin(intensities))
        i_max = float(np.nanmax(intensities))
        denom = i_max - i_min

        if not np.isfinite(denom) or denom <= 0:
            weights = np.ones_like(intensities, dtype=float)
        else:
            weights = np.clip((intensities - i_min) / denom, 0.0, 1.0)

        weights = np.power(weights, float(power))
        return float(radius_min) + (float(radius_max) - float(radius_min)) * weights

    @staticmethod
    def _default_max_tile(u: NDArray[np.float64], v: NDArray[np.float64], nrow: int, ncol: int) -> int:
        du = float(np.linalg.norm(u))
        dv = float(np.linalg.norm(v))
        dmin = min(du, dv) if (du > 0 and dv > 0) else max(du, dv)
        if not np.isfinite(dmin) or dmin <= 0:
            return 10
        diag = float(np.hypot(nrow, ncol))
        mt = int(np.ceil(diag / dmin)) + 2
        return int(np.clip(mt, 3, 200))

    @staticmethod
    def _tile_points_bounded(
        origin_rc: NDArray[np.float64],
        u_rc: NDArray[np.float64],
        v_rc: NDArray[np.float64],
        max_tile: int,
        nrow: int,
        ncol: int,
    ) -> NDArray[np.float64]:
        if max_tile == 0:
            return origin_rc[None, :].copy()

        a = np.arange(-max_tile, max_tile + 1, dtype=float)
        b = np.arange(-max_tile, max_tile + 1, dtype=float)
        aa, bb = np.meshgrid(a, b, indexing="ij")
        pts = (
            origin_rc[None, None, :]
            + aa[..., None] * u_rc[None, None, :]
            + bb[..., None] * v_rc[None, None, :]
        )
        pts = pts.reshape(-1, 2)

        keep = (
            (pts[:, 0] >= 0.0)
            & (pts[:, 0] <= (nrow - 1))
            & (pts[:, 1] >= 0.0)
            & (pts[:, 1] <= (ncol - 1))
        )
        return pts[keep]

    def _draw_peak_overlay(
        self,
        image: NDArray[np.float64],
        peaks_rc: NDArray[np.float64],
        intensities: NDArray[np.float64],
        *,
        plot_radius_min_px: float,
        plot_radius_max_px: float,
        plot_radius_power: float,
        plot_edgecolor: str,
        plot_linewidth: float,
        plot_alpha: float,
        plot_labels: bool,
        plot_label_color: Any,
        plot_label_size: float,
        plot_label_alpha: float,
        plot_label_offset_px: tuple[float, float],
        plot_label_bbox: bool,
        plot_label_bbox_facecolor: Any,
        plot_label_bbox_edgecolor: Any,
        plot_label_bbox_pad: float,
        plot_label_top_k: int | None,
        **kwargs: Any,
    ) -> tuple[Any, Any]:
        from matplotlib.patches import Circle

        fig, ax = show_2d(image, **kwargs)
        ax0 = ax.flat[0] if hasattr(ax, "flat") else ax

        if peaks_rc.size:
            radii = self._normalize_peak_radii(
                np.asarray(intensities, dtype=float),
                radius_min=float(plot_radius_min_px),
                radius_max=float(plot_radius_max_px),
                power=float(plot_radius_power),
            )

            for (row, col), radius in zip(peaks_rc, radii):
                ax0.add_patch(
                    Circle(
                        (float(col), float(row)),
                        radius=float(radius),
                        facecolor="none",
                        edgecolor=plot_edgecolor,
                        linewidth=float(plot_linewidth),
                        alpha=float(plot_alpha),
                    )
                )

            if plot_labels:
                dcol = float(plot_label_offset_px[0])
                drow = float(plot_label_offset_px[1])
                bbox_kw = None
                if plot_label_bbox:
                    bbox_kw = dict(
                        boxstyle=f"round,pad={float(plot_label_bbox_pad)}",
                        facecolor=plot_label_bbox_facecolor,
                        edgecolor=plot_label_bbox_edgecolor,
                    )

                n_labels = peaks_rc.shape[0]
                if plot_label_top_k is not None:
                    n_labels = min(n_labels, int(plot_label_top_k))

                for idx in range(n_labels):
                    row, col = float(peaks_rc[idx, 0]), float(peaks_rc[idx, 1])
                    ax0.text(
                        col + dcol,
                        row + drow,
                        str(idx),
                        color=plot_label_color,
                        fontsize=float(plot_label_size),
                        alpha=float(plot_label_alpha),
                        ha="center",
                        va="center",
                        bbox=bbox_kw,
                    )

        ax0.figure.canvas.draw_idle()
        return fig, ax0

    def _require_peak_state(self) -> tuple[PeakArray, NDArray[np.float64], NDArray[np.float64]]:
        peaks = np.asarray(self.peaks, dtype=float)
        intensities = np.asarray(self.I, dtype=float).reshape(-1)
        image = self._get_diffraction_array()

        if peaks.ndim != 2 or peaks.shape[1] != 2:
            raise RuntimeError("self.peaks must have shape (N, 2) with columns [row, col].")
        if peaks.shape[0] == 0:
            raise RuntimeError("No peaks found. Run .find_peaks() first.")
        if intensities.shape[0] != peaks.shape[0]:
            raise RuntimeError("self.I must have the same length as self.peaks.")

        return peaks, intensities, image

    def find_diffraction_center_robust(
        self,
        peaks: NDArray[Any],
        tolerance: float = 3.0,
        max_iters: int = 20_000,
        rng: np.random.Generator | None = None,
        verbose: bool = True,
    ) -> NDArray[np.float64]:
        """Estimate diffraction center from centrosymmetric peak pairs with a RANSAC-like search."""
        peaks_arr = np.asarray(peaks, dtype=float)
        n_peaks = len(peaks_arr)

        if n_peaks == 0:
            return np.zeros(2, dtype=float)
        if n_peaks == 1:
            return peaks_arr[0].astype(float, copy=True)

        if tolerance <= 0:
            raise ValueError("tolerance must be > 0.")
        if max_iters <= 0:
            raise ValueError("max_iters must be > 0.")

        rng = np.random.default_rng() if rng is None else rng
        tree = cKDTree(peaks_arr)

        best_center = np.mean(peaks_arr, axis=0)
        max_inliers = -1

        for _ in range(int(max_iters)):
            idx1, idx2 = rng.choice(n_peaks, 2, replace=False)
            candidate_center = 0.5 * (peaks_arr[idx1] + peaks_arr[idx2])

            flipped = 2.0 * candidate_center - peaks_arr
            distances, _ = tree.query(flipped, k=1)
            inliers = int(np.count_nonzero(distances < tolerance))

            if inliers > max_inliers:
                max_inliers = inliers
                best_center = candidate_center

        flipped_best = 2.0 * best_center - peaks_arr
        distances, indices = tree.query(flipped_best, k=1)
        mask = distances < tolerance

        if np.any(mask):
            midpoints = 0.5 * (peaks_arr[mask] + peaks_arr[indices[mask]])
            refined_center = np.mean(midpoints, axis=0)
        else:
            refined_center = best_center

        if verbose:
            print(
                f"Result: found {max_inliers} symmetric point pairs, "
                f"final center: {refined_center}"
            )
        return np.asarray(refined_center, dtype=float)

    def find_peaks(
        self,
        *,
        threshold: float | None = None,
        min_distance_px: float | None = None,
        max_peaks: int | None = None,
        sigma_range: tuple[float, float] = (3.0, 1.0), # [新增] 定义扫描范围
        sigma_step: float = 0.1,
        mask_diffraction: NDArray | None = None,
        refine_subpixel: bool = True,
        refine_radius_px: int = 4,
        refine_maxfev: int = 500,
        plot_result: bool = True,
        plot_radius_min_px: float = 2.0,
        plot_radius_max_px: float = 10.0,
        plot_radius_power: float = 0.5,
        plot_edgecolor: str = "r",
        plot_linewidth: float = 1.0,
        plot_alpha: float = 0.5,
        plot_labels: bool = False,
        plot_label_color: Any = (0, 0.9, 1.0),
        plot_label_size: float = 6.0,
        plot_label_alpha: float = 0.9,
        plot_label_offset_px: tuple[float, float] = (0.0, -12.0),
        plot_label_bbox: bool = True,
        plot_label_bbox_facecolor: Any = (0.0, 0.0, 0.0, 0.35),
        plot_label_bbox_edgecolor: Any = "none",
        plot_label_bbox_pad: float = 0.15,
        plot_label_top_k: int | None = None,
        return_peaks: bool = False,
        **kwargs: Any,
    ) -> dict[str, Any]:
        im = np.asarray(self.diffraction.array)
        if im.ndim != 2:
            raise ValueError("DiffractionMoire.find_peaks requires a 2D diffraction array.")

        # --- [逻辑变更] 初始化结果容器 ---
        all_detected_peaks = np.zeros((0, 2), dtype=float)
        
        # --- [新增] Sigma 递减循环扫描 ---
        # 从 3.0 降到 1.0，步长 0.1
        sigmas = np.arange(sigma_range[0], sigma_range[1] - 1e-5, -sigma_step)
        
        for s in sigmas:
            im_s = gaussian_filter(im, sigma=float(s)) if float(s) > 0 else im

            # [逻辑变更] 阈值在每一层 sigma 下动态计算（如果未手动指定）
            if threshold is None:
                mu = float(np.nanmean(im_s))
                sig = float(np.nanstd(im_s))
                curr_threshold = mu + 5.0 * sig
            else:
                curr_threshold = float(threshold)

            # [逻辑变更] NMS 窗口大小随 min_distance_px 调整
            win = max(3, int(np.ceil(min_distance_px) * 2 + 1))
            mx = maximum_filter(im_s, size=win, mode="nearest")
            cand_mask = (im_s == mx) & (im_s >= curr_threshold)

            if mask_diffraction is not None:
                cand_mask &= np.asarray(mask_diffraction).astype(bool)

            new_peaks = np.argwhere(cand_mask).astype(float)

            if new_peaks.size == 0:
                continue

            # --- [新增] 空间合并逻辑 (去重) ---
            if all_detected_peaks.size == 0:
                all_detected_peaks = new_peaks
            else:
                from scipy.spatial import cKDTree
                tree = cKDTree(all_detected_peaks)
                # 查找新点到已有点集的最近距离
                dists, _ = tree.query(new_peaks, k=1)
                
                # 只有距离大于 min_distance_px 的点才被认为是“新点”
                # 这样做保证了：如果 sigma 变化导致原有的点偏移，我们会保留大 sigma 时的稳定坐标
                unique_mask = dists > min_distance_px
                if np.any(unique_mask):
                    all_detected_peaks = np.vstack([all_detected_peaks, new_peaks[unique_mask]])

        # --- [逻辑变更] 后置排序 ---
        # 此时得到的 peaks 是多层扫描后的合并结果
        # 按照原图中的强度进行重新排序
        peak_I = im[all_detected_peaks[:, 0].astype(int), all_detected_peaks[:, 1].astype(int)].astype(float)
        order = np.argsort(-peak_I)
        self.peaks = all_detected_peaks[order]
        self.I = peak_I[order]
        peaks_rc = self.peaks

        if max_peaks is not None and self.peaks.shape[0] > int(max_peaks):
            self.peaks = self.peaks[: int(max_peaks)]
            self.I = self.I[: int(max_peaks)]

        # 构建输出字典 (初始化)
        out = {
            "peaks": self.peaks,
            "I": self.I,
            "threshold": threshold, # 记录用户输入的阈值
            "sigma_range": sigma_range,
        }

        if refine_subpixel and peaks_rc.shape[0] > 0:
            r = int(refine_radius_px)
            if r < 1:
                raise ValueError("refine_radius_px must be >= 1.")

            def _gauss2d(coords: NDArray, A: float, row0: float, col0: float, s: float, c: float) -> NDArray:
                rr, cc = coords
                return A * np.exp(-((rr - row0) ** 2 + (cc - col0) ** 2) / (2.0 * s * s)) + c

            peaks_rc_ref = peaks_rc.copy()
            I_ref = peak_I.copy()
            fit_params = np.full((peaks_rc.shape[0], 5), np.nan, dtype=float)
            fit_success = np.zeros((peaks_rc.shape[0],), dtype=bool)

            for k in range(peaks_rc.shape[0]):
                row0_i = float(peaks_rc[k, 0])
                col0_i = float(peaks_rc[k, 1])
                row_i = int(np.round(row0_i))
                col_i = int(np.round(col0_i))

                r0 = max(0, row_i - r)
                r1 = min(im_s.shape[0], row_i + r + 1)
                c0 = max(0, col_i - r)
                c1 = min(im_s.shape[1], col_i + r + 1)
                if (r1 - r0) < 3 or (c1 - c0) < 3:
                    continue

                patch = im_s[r0:r1, c0:c1].astype(float, copy=False)
                rr, cc = np.mgrid[r0:r1, c0:c1]
                xdata = np.vstack([rr.ravel(), cc.ravel()])
                ydata = patch.ravel()

                c_init = float(np.median(ydata))
                A_init = float(np.max(ydata) - c_init)
                if not np.isfinite(A_init) or A_init <= 0:
                    continue
                s_init = max(0.75, float(r) / 2.0)

                row_min = float(r0)
                row_max = float(r1 - 1)
                col_min = float(c0)
                col_max = float(c1 - 1)

                p0 = (A_init, row0_i, col0_i, s_init, c_init)
                lb = (0.0, row_min, col_min, 0.5, float(np.min(ydata) - abs(A_init)))
                ub = (
                    float(np.inf),
                    row_max,
                    col_max,
                    float(max(0.75, 2.0 * r)),
                    float(np.max(ydata) + abs(A_init)),
                )

                try:
                    popt, _ = curve_fit(
                        _gauss2d,
                        xdata,
                        ydata,
                        p0=p0,
                        bounds=(lb, ub),
                        maxfev=int(refine_maxfev),
                    )
                except Exception:
                    continue

                A_fit, row_fit, col_fit, s_fit, c_fit = (
                    float(popt[0]),
                    float(popt[1]),
                    float(popt[2]),
                    float(popt[3]),
                    float(popt[4]),
                )
                if not (np.isfinite(row_fit) and np.isfinite(col_fit) and np.isfinite(s_fit) and s_fit > 0):
                    continue

                peaks_rc_ref[k, 0] = row_fit
                peaks_rc_ref[k, 1] = col_fit
                I_ref[k] = max(A_fit + c_fit, float(im[row_i, col_i]))
                fit_params[k, :] = np.array([A_fit, row_fit, col_fit, s_fit, c_fit], dtype=float)
                fit_success[k] = True

            order_ref = np.argsort(-I_ref)
            peaks_rc_ref = peaks_rc_ref[order_ref]
            I_ref = I_ref[order_ref]
            fit_params = fit_params[order_ref]
            fit_success = fit_success[order_ref]

            out["peaks_refined"] = peaks_rc_ref
            out["I_refined"] = I_ref
            out["gaussian_fit_params"] = fit_params
            out["gaussian_fit_success"] = fit_success
            out["refine_radius_px"] = int(refine_radius_px)

            self.peaks = peaks_rc_ref
            self.I = I_ref
            out["peaks"] = peaks_rc_ref
            out["I"] = I_ref

        if plot_result:
            from matplotlib.patches import Circle

            fig, ax = show_2d(im_s, **kwargs)
            ax0 = ax.flat[0] if hasattr(ax, "flat") else ax

            peaks_plot = np.asarray(out["peaks"], dtype=float)
            I_plot = np.asarray(out["I"], dtype=float)

            if peaks_plot.size:
                I_min = float(np.nanmin(I_plot)) if I_plot.size else 0.0
                I_max = float(np.nanmax(I_plot)) if I_plot.size else 1.0
                denom = I_max - I_min
                if not np.isfinite(denom) or denom <= 0:
                    t = np.ones_like(I_plot, dtype=float)
                else:
                    t = np.clip((I_plot - I_min) / denom, 0.0, 1.0)

                t = np.power(t, float(plot_radius_power))
                radii = float(plot_radius_min_px) + (float(plot_radius_max_px) - float(plot_radius_min_px)) * t

                for (row, col), rad in zip(peaks_plot, radii):
                    ax0.add_patch(
                        Circle(
                            (col, row),
                            radius=float(rad),
                            facecolor="none",
                            edgecolor=plot_edgecolor,
                            linewidth=float(plot_linewidth),
                            alpha=float(plot_alpha),
                        )
                    )

                if plot_labels:
                    dcol, drow = float(plot_label_offset_px[0]), float(plot_label_offset_px[1])
                    bbox_kw = None
                    if plot_label_bbox:
                        bbox_kw = dict(
                            boxstyle=f"round,pad={float(plot_label_bbox_pad)}",
                            facecolor=plot_label_bbox_facecolor,
                            edgecolor=plot_label_bbox_edgecolor,
                        )

                    nlab = peaks_plot.shape[0]
                    if plot_label_top_k is not None:
                        nlab = min(nlab, int(plot_label_top_k))

                    for idx in range(nlab):
                        row, col = float(peaks_plot[idx, 0]), float(peaks_plot[idx, 1])
                        ax0.text(
                            float(col + dcol),
                            float(row + drow),
                            str(idx),
                            color=plot_label_color,
                            fontsize=float(plot_label_size),
                            alpha=float(plot_label_alpha),
                            ha="center",
                            va="center",
                            bbox=bbox_kw,
                        )

            ax0.figure.canvas.draw_idle()

        if return_peaks:
            return out

    def real_peaks_intensity_range(
        self,
        distance: float = 4.0,
        sigma: float = 1.0,
        plot_result: bool = True,
        plot_radius_min_px: float = 2.0,
        plot_radius_max_px: float = 10.0,
        plot_radius_power: float = 0.5,
        plot_edgecolor: str = "r",
        plot_linewidth: float = 1.0,
        plot_alpha: float = 0.5,
        plot_labels: bool = False,
        plot_label_color: Any = (0, 0.9, 1.0),
        plot_label_size: float = 6.0,
        plot_label_alpha: float = 0.9,
        plot_label_offset_px: tuple[float, float] = (0.0, -12.0),
        plot_label_bbox: bool = True,
        plot_label_bbox_facecolor: Any = (0.0, 0.0, 0.0, 0.35),
        plot_label_bbox_edgecolor: Any = "none",
        plot_label_bbox_pad: float = 0.15,
        plot_label_top_k: int | None = None,
        return_peaks: bool = False,
        **kwargs: Any,
    ) -> dict[str, Any]:
        del return_peaks  # kept for backward compatibility

        im = self._get_diffraction_array()
        im_s = gaussian_filter(im, sigma=float(sigma)) if float(sigma) > 0 else im
        peaks, _, _ = self._require_peak_state()

        dist = int(np.ceil(distance if distance is not None else 4.0))
        if dist <= 0:
            raise ValueError("distance must be > 0.")

        nrow, ncol = im.shape
        intensities: list[float] = []
        for row_f, col_f in peaks:
            row = int(np.rint(row_f))
            col = int(np.rint(col_f))
            row0 = max(row - dist, 0)
            row1 = min(row + dist + 1, nrow)
            col0 = max(col - dist, 0)
            col1 = min(col + dist + 1, ncol)
            patch = im[row0:row1, col0:col1]
            intensities.append(float(np.max(patch)))

        I_arr = np.asarray(intensities, dtype=float)
        order = np.argsort(-I_arr)
        peaks_rc_ref = peaks[order]
        I_ref = I_arr[order]

        self.peaks = peaks_rc_ref
        self.I = I_ref
        out = {"peaks": peaks_rc_ref, "I": I_ref.copy()}

        if plot_result:
            self._draw_peak_overlay(
                im_s,
                peaks_rc=peaks_rc_ref,
                intensities=I_ref,
                plot_radius_min_px=plot_radius_min_px,
                plot_radius_max_px=plot_radius_max_px,
                plot_radius_power=plot_radius_power,
                plot_edgecolor=plot_edgecolor,
                plot_linewidth=plot_linewidth,
                plot_alpha=plot_alpha,
                plot_labels=plot_labels,
                plot_label_color=plot_label_color,
                plot_label_size=plot_label_size,
                plot_label_alpha=plot_label_alpha,
                plot_label_offset_px=plot_label_offset_px,
                plot_label_bbox=plot_label_bbox,
                plot_label_bbox_facecolor=plot_label_bbox_facecolor,
                plot_label_bbox_edgecolor=plot_label_bbox_edgecolor,
                plot_label_bbox_pad=plot_label_bbox_pad,
                plot_label_top_k=plot_label_top_k,
                **kwargs,
            )

        return out



    def _plot_auto_find_lattice_debug(
        self,
        image: NDArray[np.float64],
        peaks: NDArray[np.float64],
        *,
        center_peak_index: int,
        selected_groups: list[dict[str, Any]],
        moire_matched_global: list[int] | None = None,
        top_candidates: list[dict[str, Any]] | None = None,
        log_scale: bool = True,
        annotate_peaks: bool = False,
        figsize: tuple[float, float] | None = None,
        title: str | None = None,
    ) -> tuple[Any, Any]:
        """Visualize auto-selected lattice vectors and their supported peaks."""
        import matplotlib.pyplot as plt

        num_groups = max(len(selected_groups), 1)
        ncols = num_groups + 1
        if figsize is None:
            figsize = (5.5 * ncols, 5.5)

        disp = np.asarray(image, dtype=float)
        if log_scale:
            disp = np.log1p(np.clip(disp, 0.0, None))

        fig, axes = plt.subplots(1, ncols, figsize=figsize, squeeze=False)
        axes = axes.ravel()
        colors = ["tab:red", "tab:cyan", "tab:orange", "tab:green", "tab:purple"]
        origin = np.asarray(peaks[center_peak_index], dtype=float)
        moire_matched_global = [] if moire_matched_global is None else list(moire_matched_global)
        top_candidates = [] if top_candidates is None else list(top_candidates)

        def _setup_axis(ax: Any, subtitle: str) -> None:
            ax.imshow(disp, cmap="gray", origin="upper")
            if peaks.size:
                ax.scatter(peaks[:, 1], peaks[:, 0], s=12, c="white", alpha=0.35, linewidths=0)
            ax.scatter([origin[1]], [origin[0]], s=160, marker="*", c="gold", edgecolors="black", linewidths=0.8)
            if annotate_peaks and peaks.size:
                for idx, (r, c) in enumerate(peaks):
                    ax.text(float(c) + 2.0, float(r) - 2.0, str(idx), color="lime", fontsize=7)
            ax.set_title(subtitle)
            ax.set_aspect("equal")
            ax.set_xlim(-0.5, disp.shape[1] - 0.5)
            ax.set_ylim(disp.shape[0] - 0.5, -0.5)

        ax0 = axes[0]
        _setup_axis(ax0, "Selected lattices (summary)")
        if moire_matched_global:
            moire_pts = peaks[np.asarray(moire_matched_global, dtype=int)]
            ax0.scatter(moire_pts[:, 1], moire_pts[:, 0], s=40, marker="x", c="magenta", linewidths=1.2, label="moire-matched")

        legend_handles = []
        legend_labels = []
        for gi, info in enumerate(selected_groups):
            color = colors[gi % len(colors)]
            supported_global = np.asarray(info.get("supported_global", []), dtype=int)
            if supported_global.size:
                pts = peaks[supported_global]
                handle = ax0.scatter(pts[:, 1], pts[:, 0], s=28, c=color, alpha=0.85, edgecolors="black", linewidths=0.25)
                legend_handles.append(handle)
                legend_labels.append(f"L{gi+1}: {supported_global.size} peaks")
            pair_global = tuple(info["pair_global"])
            pair_pts = peaks[np.asarray(pair_global, dtype=int)]
            ax0.scatter(pair_pts[:, 1], pair_pts[:, 0], s=90, facecolors="none", edgecolors=color, linewidths=2.0)
            for end_pt in pair_pts:
                dr = float(end_pt[0] - origin[0])
                dc = float(end_pt[1] - origin[1])
                ax0.arrow(float(origin[1]), float(origin[0]), dc, dr, color=color, width=0.0, head_width=4.0, head_length=6.0, length_includes_head=True, alpha=0.9)
        if legend_handles:
            ax0.legend(legend_handles, legend_labels, loc="best", fontsize=8)

        for gi, info in enumerate(selected_groups):
            ax = axes[gi + 1]
            color = colors[gi % len(colors)]
            _setup_axis(ax, f"Lattice {gi+1}")
            supported_global = np.asarray(info.get("supported_global", []), dtype=int)
            if supported_global.size:
                pts = peaks[supported_global]
                ax.scatter(pts[:, 1], pts[:, 0], s=34, c=color, alpha=0.95, edgecolors="black", linewidths=0.3)
            pair_global = tuple(info["pair_global"])
            pair_pts = peaks[np.asarray(pair_global, dtype=int)]
            ax.scatter(pair_pts[:, 1], pair_pts[:, 0], s=100, facecolors="none", edgecolors=color, linewidths=2.2)
            for end_pt in pair_pts:
                dr = float(end_pt[0] - origin[0])
                dc = float(end_pt[1] - origin[1])
                ax.arrow(float(origin[1]), float(origin[0]), dc, dr, color=color, width=0.0, head_width=4.0, head_length=6.0, length_includes_head=True, alpha=0.95)
            ax.text(
                0.02,
                0.98,
                f"score = {float(info.get('score', float('nan'))):.2f}\ncount = {int(info.get('supported_count', len(supported_global)))}",
                transform=ax.transAxes,
                ha="left",
                va="top",
                fontsize=9,
                color="white",
                bbox=dict(boxstyle="round,pad=0.2", facecolor=(0, 0, 0, 0.45), edgecolor="none"),
            )

        if top_candidates:
            lines = ["Top candidates:"]
            for cand in top_candidates:
                lines.append(
                    f"{cand['rank']}: pair={tuple(cand['pair_global'])}, score={cand['score']:.2f}, n={cand['supported_count']}"
                )
            fig.text(
                0.5,
                0.01,
                " | ".join(lines),
                ha="center",
                va="bottom",
                fontsize=9,
            )

        if title is not None:
            fig.suptitle(title)
        fig.tight_layout(rect=(0.0, 0.04 if top_candidates else 0.0, 1.0, 0.95 if title else 1.0))
        return fig, axes


    def auto_find_lattice_vectors(
        self,
        peaks_number: int = 150,
        num: int = 3,
        center_search_radius: float = 10.0,
        outer_radius_start: float = 50.0,
        outer_radius_step: float = 10.0,
        match_radius: float = 4.0,
        angle_range_deg: tuple[float, float] = (40.0, 140.0),
        projection_tol: float = 0.35,
        batch_size: int = 2048,
        verbose: bool = False,
        debug_visualize: bool = False,
        debug_return: bool = False,
        debug_log_scale: bool = True,
        debug_annotate_peaks: bool = False,
        debug_max_candidates: int = 8,
        debug_figsize: tuple[float, float] | None = None,
    ) -> list[int] | dict[str, Any]:
        """Automatically identify 2 or 3 non-overlapping lattice basis pairs.

        This optimized version avoids repeated lattice tiling for every candidate pair.
        Each candidate basis is scored by projecting detected peaks onto the candidate
        basis and checking whether those peaks lie close to integer lattice coordinates.
        """
        if num not in {2, 3}:
            raise ValueError("num must be 2 or 3.")
        if peaks_number < 3:
            raise ValueError("peaks_number must be >= 3.")
        if center_search_radius <= 0 or outer_radius_step <= 0 or match_radius <= 0:
            raise ValueError("center_search_radius, outer_radius_step, and match_radius must be > 0.")
        if projection_tol <= 0:
            raise ValueError("projection_tol must be > 0.")
        if batch_size < 1:
            raise ValueError("batch_size must be >= 1.")

        peaks, intensity, im = self._require_peak_state()
        peaks_work = peaks.copy()
        intensity_work = intensity.copy()
        nrow, ncol = int(im.shape[0]), int(im.shape[1])

        true_center = self.find_diffraction_center_robust(peaks_work, verbose=verbose)
        dists_to_true = np.linalg.norm(peaks_work - true_center, axis=1)
        near_center = np.flatnonzero(dists_to_true < float(center_search_radius))

        if near_center.size:
            center_peak_index = int(near_center[np.argmax(intensity_work[near_center])])
            peaks_work[center_peak_index] = true_center
            self.peaks[center_peak_index] = true_center
        else:
            center_peak_index = int(peaks_work.shape[0])
            peaks_work = np.vstack([peaks_work, true_center[None, :]])
            intensity_work = np.append(intensity_work, 0.0)
            self.peaks = np.vstack([self.peaks, true_center[None, :]])
            self.I = np.append(self.I, 0.0)
            if verbose:
                print(f"No peak near the diffraction center; appended a synthetic center at index {center_peak_index}.")

        origin = peaks_work[center_peak_index].astype(float, copy=False)
        max_radius = max(int(min(nrow, ncol) // 2), int(np.ceil(outer_radius_start + outer_radius_step)))

        def _generate_two_lattice_moire_points(
            r0: NDArray[np.float64],
            u1: NDArray[np.float64],
            v1: NDArray[np.float64],
            u2: NDArray[np.float64],
            v2: NDArray[np.float64],
            *,
            maxlen: float | None = None,
            r_excl: float = 2.0,
            decimals: int = 3,
        ) -> NDArray[np.float64] | None:
            maxlen_use = float(maxlen) if maxlen is not None else float(0.5 * np.hypot(nrow, ncol))

            def _disp_set(u: NDArray[np.float64], v: NDArray[np.float64]) -> tuple[NDArray[np.float64], NDArray[np.float64]]:
                dmin = float(min(np.linalg.norm(u), np.linalg.norm(v)))
                if not np.isfinite(dmin) or dmin <= 0:
                    return np.zeros((0, 2), dtype=float), np.zeros((0, 2), dtype=float)
                mt = int(np.ceil(maxlen_use / dmin)) + 1
                mt = int(np.clip(mt, 1, 200))
                a = np.arange(-mt, mt + 1, dtype=float)
                b = np.arange(-mt, mt + 1, dtype=float)
                aa, bb = np.meshgrid(a, b, indexing="ij")
                aa = aa.ravel()
                bb = bb.ravel()
                disp = aa[:, None] * u[None, :] + bb[:, None] * v[None, :]
                keep = np.linalg.norm(disp, axis=1) <= maxlen_use + 1e-9
                return disp[keep], np.stack([aa[keep], bb[keep]], axis=1)

            disp1, ab1 = _disp_set(u1, v1)
            disp2, ab2 = _disp_set(u2, v2)
            if disp1.size == 0 or disp2.size == 0:
                return None

            n1, n2 = int(disp1.shape[0]), int(disp2.shape[0])
            if n1 * n2 > 2_000_000:
                return None

            pts = r0[None, None, :] + disp1[:, None, :] + disp2[None, :, :]
            pts = pts.reshape(-1, 2)

            keep_combo = ~(
                ((ab1[:, 0] == 0) & (ab1[:, 1] == 0))[:, None]
                | ((ab2[:, 0] == 0) & (ab2[:, 1] == 0))[None, :]
            ).ravel()
            pts = pts[keep_combo]

            keep_bounds = (
                (pts[:, 0] >= 0.0)
                & (pts[:, 0] <= (nrow - 1))
                & (pts[:, 1] >= 0.0)
                & (pts[:, 1] <= (ncol - 1))
            )
            pts = pts[keep_bounds]
            if pts.size == 0:
                return None

            pts = np.unique(np.round(pts, int(decimals)), axis=0)
            if r_excl > 0:
                parent_pts = np.vstack((r0[None, :] + disp1, r0[None, :] + disp2))
                parent_keep = (
                    (parent_pts[:, 0] >= 0.0)
                    & (parent_pts[:, 0] <= (nrow - 1))
                    & (parent_pts[:, 1] >= 0.0)
                    & (parent_pts[:, 1] <= (ncol - 1))
                )
                parent_pts = parent_pts[parent_keep]
                if parent_pts.size:
                    tree = cKDTree(parent_pts)
                    d, _ = tree.query(pts, k=1)
                    pts = pts[d >= float(r_excl)]
            return pts if pts.size else None

        def _cap_filtered_indices(filtered_idx: NDArray[np.int_]) -> NDArray[np.int_]:
            filtered_idx = np.asarray(filtered_idx, dtype=int)
            if filtered_idx.size <= peaks_number:
                return filtered_idx
            non_center = filtered_idx[filtered_idx != center_peak_index]
            order = np.argsort(-intensity_work[non_center])
            keep_non_center = non_center[order[: max(peaks_number - 1, 0)]]
            keep = np.concatenate(([center_peak_index], keep_non_center))
            keep = np.unique(keep)
            return keep

        def _candidate_pairs(filtered_peaks: NDArray[np.float64], center_local_idx: int) -> NDArray[np.int_]:
            local_indices = np.arange(filtered_peaks.shape[0], dtype=int)
            use = local_indices[local_indices != center_local_idx]
            if use.size < 2:
                return np.zeros((0, 2), dtype=int)

            ii, jj = np.triu_indices(use.size, k=1)
            pairs = np.column_stack((use[ii], use[jj]))
            u = filtered_peaks[pairs[:, 0]] - origin
            v = filtered_peaks[pairs[:, 1]] - origin
            norm_u = np.linalg.norm(u, axis=1)
            norm_v = np.linalg.norm(v, axis=1)
            dot = np.sum(u * v, axis=1)
            cos_theta = np.clip(dot / (norm_u * norm_v + 1e-12), -1.0, 1.0)
            angle = np.degrees(np.arccos(cos_theta))
            det = u[:, 0] * v[:, 1] - u[:, 1] * v[:, 0]
            keep = (
                (norm_u > 0.0)
                & (norm_v > 0.0)
                & (np.abs(det) > 1e-6)
                & (angle >= float(angle_range_deg[0]))
                & (angle <= float(angle_range_deg[1]))
            )
            return pairs[keep]

        def _score_pairs_fast(
            filtered_peaks: NDArray[np.float64],
            filtered_intensity: NDArray[np.float64],
            pairs_local: NDArray[np.int_],
            center_local_idx: int,
        ) -> list[dict[str, Any]]:
            if pairs_local.size == 0:
                return []

            rel = filtered_peaks - origin
            infos: list[dict[str, Any]] = []
            for start in range(0, pairs_local.shape[0], int(batch_size)):
                batch_pairs = pairs_local[start : start + int(batch_size)]
                u = rel[batch_pairs[:, 0]]
                v = rel[batch_pairs[:, 1]]
                det = u[:, 0] * v[:, 1] - u[:, 1] * v[:, 0]
                good = np.abs(det) > 1e-8
                if not np.any(good):
                    continue

                batch_pairs = batch_pairs[good]
                u = u[good]
                v = v[good]
                det = det[good]
                inv = np.empty((batch_pairs.shape[0], 2, 2), dtype=float)
                inv[:, 0, 0] = v[:, 1] / det
                inv[:, 0, 1] = -v[:, 0] / det
                inv[:, 1, 0] = -u[:, 1] / det
                inv[:, 1, 1] = u[:, 0] / det

                coeff = np.einsum("bij,nj->bni", inv, rel)
                coeff_round = np.rint(coeff)
                coeff_err = np.abs(coeff - coeff_round)
                close_integer = np.max(coeff_err, axis=2) <= float(projection_tol)

                recon = (
                    coeff_round[:, :, 0][:, :, None] * u[:, None, :]
                    + coeff_round[:, :, 1][:, :, None] * v[:, None, :]
                )
                residual = np.linalg.norm(recon - rel[None, :, :], axis=2)
                explained = close_integer & (residual <= float(match_radius))
                explained[:, center_local_idx] = True

                scores = explained @ filtered_intensity
                for row_idx in range(batch_pairs.shape[0]):
                    supported = np.flatnonzero(explained[row_idx])
                    if supported.size == 0:
                        continue
                    infos.append(
                        {
                            "pair_local": (int(batch_pairs[row_idx, 0]), int(batch_pairs[row_idx, 1])),
                            "supported_local": supported.astype(int, copy=False),
                            "score": float(scores[row_idx]),
                        }
                    )
            infos.sort(key=lambda x: x["score"], reverse=True)
            return infos

        selected_pairs_global: list[tuple[int, int]] = []
        debug_payload: dict[str, Any] | None = None
        last_candidate_snapshot: dict[str, Any] | None = None
        for current_mask_r in np.arange(float(outer_radius_start), float(max_radius) + 1e-9, float(outer_radius_step)):
            dist = np.linalg.norm(peaks_work - origin, axis=1)
            keep_global = np.flatnonzero((dist >= current_mask_r) | (np.arange(peaks_work.shape[0]) == center_peak_index))
            keep_global = _cap_filtered_indices(keep_global)
            if keep_global.size < 5:
                continue

            filtered_peaks = peaks_work[keep_global]
            filtered_intensity = intensity_work[keep_global]
            center_local_candidates = np.flatnonzero(keep_global == center_peak_index)
            if center_local_candidates.size == 0:
                continue
            center_local_idx = int(center_local_candidates[0])

            candidate_pairs = _candidate_pairs(filtered_peaks, center_local_idx)
            pair_infos = _score_pairs_fast(filtered_peaks, filtered_intensity, candidate_pairs, center_local_idx)
            if not pair_infos:
                continue

            last_candidate_snapshot = {
                "mask_radius": float(current_mask_r),
                "filtered_indices": keep_global.astype(int, copy=False),
                "top_candidates": pair_infos[: max(int(debug_max_candidates), 0)],
            }

            chosen: list[dict[str, Any]] = []
            forbidden_local_sets: list[set[int]] = []
            moire_matched_local: set[int] = set()

            for info in pair_infos:
                supported_no_center = {int(i) for i in info["supported_local"] if int(i) != center_local_idx}
                if any(supported_no_center & used for used in forbidden_local_sets):
                    continue

                endpoints = {int(info["pair_local"][0]), int(info["pair_local"][1])}
                if moire_matched_local and endpoints & moire_matched_local:
                    continue

                info["pair_global"] = (
                    int(keep_global[info["pair_local"][0]]),
                    int(keep_global[info["pair_local"][1]]),
                )
                chosen.append(info)
                forbidden_local_sets.append(supported_no_center)

                if len(chosen) == 2 and num >= 3:
                    u1_local, v1_local = chosen[0]["pair_local"]
                    u2_local, v2_local = chosen[1]["pair_local"]
                    pts_moire = _generate_two_lattice_moire_points(
                        origin,
                        filtered_peaks[u1_local] - origin,
                        filtered_peaks[v1_local] - origin,
                        filtered_peaks[u2_local] - origin,
                        filtered_peaks[v2_local] - origin,
                        r_excl=2.0,
                    )
                    moire_matched_local = set()
                    if pts_moire is not None and pts_moire.size:
                        moire_tree = cKDTree(pts_moire)
                        neighbors = moire_tree.query_ball_point(filtered_peaks, r=float(match_radius))
                        moire_matched_local = {
                            int(i) for i, ids in enumerate(neighbors) if ids and i != center_local_idx
                        }

                if len(chosen) >= num:
                    break

            if len(chosen) >= num:
                selected_pairs_global = [info["pair_global"] for info in chosen[:num]]
                chosen_use = chosen[:num]
                moire_global = sorted(
                    int(keep_global[i]) for i in moire_matched_local if int(i) != center_local_idx
                )
                selected_groups: list[dict[str, Any]] = []
                for group_id, info in enumerate(chosen_use, start=1):
                    supported_global = keep_global[np.asarray(info["supported_local"], dtype=int)]
                    supported_global = np.unique(supported_global.astype(int, copy=False))
                    pair_global = tuple(int(x) for x in info["pair_global"])
                    pair_pts = peaks_work[np.asarray(pair_global, dtype=int)]
                    selected_groups.append(
                        {
                            "group": int(group_id),
                            "pair_global": pair_global,
                            "pair_local": tuple(int(x) for x in info["pair_local"]),
                            "score": float(info["score"]),
                            "supported_global": supported_global.tolist(),
                            "supported_count": int(supported_global.size),
                            "u_rc": (pair_pts[0] - origin).astype(float).tolist(),
                            "v_rc": (pair_pts[1] - origin).astype(float).tolist(),
                        }
                    )

                top_candidates: list[dict[str, Any]] = []
                for rank, cand in enumerate(pair_infos[: max(int(debug_max_candidates), 0)], start=1):
                    cand_supported_global = keep_global[np.asarray(cand["supported_local"], dtype=int)]
                    top_candidates.append(
                        {
                            "rank": int(rank),
                            "pair_global": tuple(int(keep_global[i]) for i in cand["pair_local"]),
                            "score": float(cand["score"]),
                            "supported_count": int(np.unique(cand_supported_global).size),
                        }
                    )

                debug_payload = {
                    "center_peak_index": int(center_peak_index),
                    "center_rc": origin.astype(float).tolist(),
                    "num_requested": int(num),
                    "mask_radius_used": float(current_mask_r),
                    "match_radius": float(match_radius),
                    "projection_tol": float(projection_tol),
                    "filtered_indices": keep_global.astype(int).tolist(),
                    "selected_groups": selected_groups,
                    "moire_matched_global": moire_global,
                    "top_candidates": top_candidates,
                }
                break

        if len(selected_pairs_global) < num:
            raise RuntimeError(
                f"Unable to identify {num} non-overlapping lattice pairs from the detected peaks."
            )

        results: list[int] = [int(center_peak_index)]
        for u_idx, v_idx in selected_pairs_global[:num]:
            results.extend([int(u_idx), int(v_idx)])

        if debug_payload is None:
            debug_payload = {
                "center_peak_index": int(center_peak_index),
                "center_rc": origin.astype(float).tolist(),
                "num_requested": int(num),
                "mask_radius_used": None,
                "match_radius": float(match_radius),
                "projection_tol": float(projection_tol),
                "filtered_indices": [] if last_candidate_snapshot is None else np.asarray(last_candidate_snapshot["filtered_indices"], dtype=int).tolist(),
                "selected_groups": [],
                "moire_matched_global": [],
                "top_candidates": [] if last_candidate_snapshot is None else [
                    {
                        "rank": int(rank),
                        "pair_global": tuple(int(np.asarray(last_candidate_snapshot["filtered_indices"], dtype=int)[i]) for i in cand["pair_local"]),
                        "score": float(cand["score"]),
                        "supported_count": int(np.unique(np.asarray(last_candidate_snapshot["filtered_indices"], dtype=int)[np.asarray(cand["supported_local"], dtype=int)]).size),
                    }
                    for rank, cand in enumerate(last_candidate_snapshot["top_candidates"], start=1)
                ],
            }

        self.lattice_vectors_data["auto_find_debug"] = debug_payload

        if debug_visualize:
            self._plot_auto_find_lattice_debug(
                im,
                np.asarray(self.peaks, dtype=float),
                center_peak_index=int(debug_payload["center_peak_index"]),
                selected_groups=list(debug_payload["selected_groups"]),
                moire_matched_global=list(debug_payload.get("moire_matched_global", [])),
                top_candidates=list(debug_payload.get("top_candidates", [])),
                log_scale=bool(debug_log_scale),
                annotate_peaks=bool(debug_annotate_peaks),
                figsize=debug_figsize,
                title=f"auto_find_lattice_vectors(num={num})",
            )

        if verbose:
            print(f"Selected lattice indices: {results}")
        if debug_return:
            return {
                "indices": results,
                "debug": debug_payload,
            }
        return results



    def lattice_vectors(
        self,
        ind_origin: int | None = None,
        ind_u1: int | None = None,
        ind_v1: int | None = None,
        ind_u2: int | None = None,
        ind_v2: int | None = None,
        ind_u3: int | None = None,
        ind_v3: int | None = None,
        max_tile: int | None = None,
        moire_draw: bool = False,
        draw_moire12: bool = True,
        draw_moire13: bool = True,
        draw_moire23: bool = True,
        draw_moire123: bool = False,
        draw_moire123_all: bool = False,
        color_origin: Any = (0.0, 1.0, 0.0),
        color_lattice1: Any = (1.0, 0.0, 0.0),
        color_lattice2: Any = (0.0, 0.8, 1.0),
        color_lattice3: Any = (0.0, 1.0, 0.5),
        color_moire12: Any = (1.0, 0.5, 0.0),
        color_moire13: Any = (0.6, 0.0, 1.0),
        color_moire23: Any = (0.2, 0.9, 0.2),
        color_moire123_all: Any = (0.8, 0.0, 1.0),
        color_moire123_extra: Any = (0.0, 0.0, 0.0),
        alpha_lattice_pts: float = 0.8,
        alpha_moire_pair: float = 0.9,
        alpha_moire123_all: float = 0.25,
        alpha_moire123_extra: float = 0.95,
        s_origin: float = 90.0,
        s_vec_tip: float = 45.0,
        s_lattice_pts: float = 22.0,
        s_moire_pair: float = 14.0,
        s_moire123_all: float = 10.0,
        s_moire123_extra: float = 22.0,
        lw_vec: float = 1.2,
        vec_label_fontsize: float = 9.0,
        vec_label_box_alpha: float = 0.6,
        moire_exclude_radius_px: float = 2.0,
        moire_parent_maxlen_px: float | None = None,
        moire_round_decimals: int = 3,
        return_peaks: bool = False,
        **kwargs: Any,
    ) -> dict[str, Any]:
        del vec_label_fontsize, vec_label_box_alpha  # kept for backward compatibility

        peaks, _, im = self._require_peak_state()
        nrow, ncol = int(im.shape[0]), int(im.shape[1])

        def _as_int(x: int | None, name: str) -> int:
            if x is None:
                raise ValueError(f"{name} must be provided (int index into self.peaks).")
            xi = int(x)
            if xi < 0 or xi >= peaks.shape[0]:
                raise IndexError(f"{name}={xi} out of range for self.peaks with N={peaks.shape[0]}.")
            return xi

        def _pair_ok(a: int | None, b: int | None) -> bool:
            return (a is not None) and (b is not None)

        def _pair_half(a: int | None, b: int | None) -> bool:
            return (a is None) ^ (b is None)

        if _pair_half(ind_u1, ind_v1):
            raise ValueError("Provide both ind_u1 and ind_v1, or neither.")
        if _pair_half(ind_u2, ind_v2):
            raise ValueError("Provide both ind_u2 and ind_v2, or neither.")
        if _pair_half(ind_u3, ind_v3):
            raise ValueError("Provide both ind_u3 and ind_v3, or neither.")

        have_lattice1 = _pair_ok(ind_u1, ind_v1)
        have_lattice2 = _pair_ok(ind_u2, ind_v2)
        have_lattice3 = _pair_ok(ind_u3, ind_v3)
        n_lattices = int(have_lattice1) + int(have_lattice2) + int(have_lattice3)
        if n_lattices == 0:
            raise ValueError("Provide lattice indices for at least one lattice.")
        if moire_draw and n_lattices < 2:
            raise ValueError("moire_draw=True requires at least two lattices.")

        ind_origin_i = _as_int(ind_origin, "ind_origin")
        origin_rc = peaks[ind_origin_i].astype(float, copy=False)

        def _vector_pair(ind_u: int | None, ind_v: int | None, name: str) -> tuple[int | None, int | None, NDArray[np.float64] | None, NDArray[np.float64] | None]:
            if ind_u is None or ind_v is None:
                return None, None, None, None
            ind_u_i = _as_int(ind_u, f"ind_u{name}")
            ind_v_i = _as_int(ind_v, f"ind_v{name}")
            u = peaks[ind_u_i].astype(float, copy=False) - origin_rc
            v = peaks[ind_v_i].astype(float, copy=False) - origin_rc
            if np.linalg.norm(u) == 0 or np.linalg.norm(v) == 0:
                raise ValueError(f"Lattice {name} vectors must be non-zero.")
            return ind_u_i, ind_v_i, u, v

        ind_u1_i, ind_v1_i, u1, v1 = _vector_pair(ind_u1, ind_v1, "1")
        ind_u2_i, ind_v2_i, u2, v2 = _vector_pair(ind_u2, ind_v2, "2")
        ind_u3_i, ind_v3_i, u3, v3 = _vector_pair(ind_u3, ind_v3, "3")

        if max_tile is None:
            mt_candidates: list[int] = []
            if have_lattice1:
                mt_candidates.append(self._default_max_tile(u1, v1, nrow=nrow, ncol=ncol))
            if have_lattice2:
                mt_candidates.append(self._default_max_tile(u2, v2, nrow=nrow, ncol=ncol))
            if have_lattice3:
                mt_candidates.append(self._default_max_tile(u3, v3, nrow=nrow, ncol=ncol))
            max_tile_use = max(mt_candidates) if mt_candidates else 10
        else:
            max_tile_use = int(max_tile)
            if max_tile_use < 0:
                raise ValueError("max_tile must be >= 0.")

        pts1 = self._tile_points_bounded(origin_rc, u1, v1, max_tile_use, nrow=nrow, ncol=ncol) if have_lattice1 else None
        pts2 = self._tile_points_bounded(origin_rc, u2, v2, max_tile_use, nrow=nrow, ncol=ncol) if have_lattice2 else None
        pts3 = self._tile_points_bounded(origin_rc, u3, v3, max_tile_use, nrow=nrow, ncol=ncol) if have_lattice3 else None

        pts_moire_12 = None
        pts_moire_13 = None
        pts_moire_23 = None
        pts_moire_123 = None
        pts_moire_123_extra = None

        if moire_draw:
            maxlen = (
                float(moire_parent_maxlen_px)
                if moire_parent_maxlen_px is not None
                else float(0.5 * np.hypot(nrow, ncol))
            )

            def _disp_set(
                u: NDArray[np.float64] | None,
                v: NDArray[np.float64] | None,
            ) -> tuple[NDArray[np.float64], NDArray[np.float64]]:
                if u is None or v is None:
                    return np.zeros((0, 2), dtype=float), np.zeros((0, 2), dtype=float)

                dmin = float(min(np.linalg.norm(u), np.linalg.norm(v)))
                if not np.isfinite(dmin) or dmin <= 0:
                    return np.zeros((0, 2), dtype=float), np.zeros((0, 2), dtype=float)

                mt = int(np.clip(np.ceil(maxlen / dmin) + 1, 1, 100))
                a = np.arange(-mt, mt + 1, dtype=float)
                aa, bb = np.meshgrid(a, a, indexing="ij")
                aa = aa.ravel()
                bb = bb.ravel()
                disp = aa[:, None] * u[None, :] + bb[:, None] * v[None, :]
                keep = np.linalg.norm(disp, axis=1) <= maxlen + 1e-9
                return disp[keep], np.stack([aa[keep], bb[keep]], axis=1)

            def _bounds_filter(pts: NDArray[np.float64] | None) -> NDArray[np.float64] | None:
                if pts is None or pts.size == 0:
                    return None
                keep = (
                    (pts[:, 0] >= 0.0)
                    & (pts[:, 0] <= (nrow - 1))
                    & (pts[:, 1] >= 0.0)
                    & (pts[:, 1] <= (ncol - 1))
                )
                pts = pts[keep]
                return pts if pts.size else None

            def _unique_round(pts: NDArray[np.float64] | None) -> NDArray[np.float64] | None:
                if pts is None or pts.size == 0:
                    return None
                pts = np.unique(np.round(pts, int(moire_round_decimals)), axis=0)
                return pts if pts.size else None

            def _exclude_parent(
                pts: NDArray[np.float64] | None,
                parent_pts: NDArray[np.float64],
                r_excl: float,
            ) -> NDArray[np.float64] | None:
                if pts is None or pts.size == 0:
                    return None
                if float(r_excl) <= 0:
                    return pts
                if parent_pts.size == 0:
                    return pts

                keep_parent = (
                    (parent_pts[:, 0] >= 0.0)
                    & (parent_pts[:, 0] <= (nrow - 1))
                    & (parent_pts[:, 1] >= 0.0)
                    & (parent_pts[:, 1] <= (ncol - 1))
                )
                parent_pts = parent_pts[keep_parent]
                if parent_pts.size == 0:
                    return pts

                tree = cKDTree(parent_pts)
                d, _ = tree.query(pts, k=1)
                pts = pts[d >= float(r_excl)]
                return pts if pts.size else None

            def _moire_two(
                d_a: NDArray[np.float64],
                ab_a: NDArray[np.float64],
                d_b: NDArray[np.float64],
                ab_b: NDArray[np.float64],
                r_excl: float,
            ) -> NDArray[np.float64] | None:
                if d_a.size == 0 or d_b.size == 0:
                    return None
                n_a, n_b = int(d_a.shape[0]), int(d_b.shape[0])
                if n_a * n_b > 2_000_000:
                    raise ValueError(f"Moire two-lattice candidates too large: {n_a * n_b}")

                pts = origin_rc[None, None, :] + d_a[:, None, :] + d_b[None, :, :]
                pts = pts.reshape(-1, 2)

                z_a = (ab_a[:, 0] == 0) & (ab_a[:, 1] == 0)
                z_b = (ab_b[:, 0] == 0) & (ab_b[:, 1] == 0)
                keep_combo = ~(z_a[:, None] | z_b[None, :]).ravel()
                pts = pts[keep_combo]

                pts = _bounds_filter(pts)
                pts = _unique_round(pts)
                if pts is None:
                    return None

                parent_pts = np.vstack((origin_rc[None, :] + d_a, origin_rc[None, :] + d_b))
                return _exclude_parent(pts, parent_pts, r_excl)

            def _moire_three(
                d1: NDArray[np.float64],
                ab1: NDArray[np.float64],
                d2: NDArray[np.float64],
                ab2: NDArray[np.float64],
                d3: NDArray[np.float64],
                ab3: NDArray[np.float64],
                r_excl: float,
            ) -> NDArray[np.float64] | None:
                if d1.size == 0 or d2.size == 0 or d3.size == 0:
                    return None
                n1, n2, n3 = int(d1.shape[0]), int(d2.shape[0]), int(d3.shape[0])
                if n1 * n2 * n3 > 2_000_000:
                    raise ValueError(f"Moire three-lattice candidates too large: {n1 * n2 * n3}")

                pts = (
                    origin_rc[None, None, None, :]
                    + d1[:, None, None, :]
                    + d2[None, :, None, :]
                    + d3[None, None, :, :]
                )
                pts = pts.reshape(-1, 2)

                z1 = (ab1[:, 0] == 0) & (ab1[:, 1] == 0)
                z2 = (ab2[:, 0] == 0) & (ab2[:, 1] == 0)
                z3 = (ab3[:, 0] == 0) & (ab3[:, 1] == 0)
                is_parent = (
                    (z1[:, None, None] & z2[None, :, None])
                    | (z1[:, None, None] & z3[None, None, :])
                    | (z2[None, :, None] & z3[None, None, :])
                ).ravel()
                pts = pts[~is_parent]

                pts = _bounds_filter(pts)
                pts = _unique_round(pts)
                if pts is None:
                    return None

                parent_pts = np.vstack((origin_rc[None, :] + d1, origin_rc[None, :] + d2, origin_rc[None, :] + d3))
                return _exclude_parent(pts, parent_pts, r_excl)

            def _pts_key(pts: NDArray[np.float64]) -> NDArray[Any]:
                arr = np.ascontiguousarray(np.round(pts, int(moire_round_decimals)))
                return arr.view(np.dtype((np.void, arr.dtype.itemsize * arr.shape[1]))).ravel()

            need_d1 = have_lattice1 and (draw_moire12 or draw_moire13 or draw_moire123)
            need_d2 = have_lattice2 and (draw_moire12 or draw_moire23 or draw_moire123)
            need_d3 = have_lattice3 and (draw_moire13 or draw_moire23 or draw_moire123)

            d1, ab1 = _disp_set(u1, v1) if need_d1 else (np.zeros((0, 2)), np.zeros((0, 2)))
            d2, ab2 = _disp_set(u2, v2) if need_d2 else (np.zeros((0, 2)), np.zeros((0, 2)))
            d3, ab3 = _disp_set(u3, v3) if need_d3 else (np.zeros((0, 2)), np.zeros((0, 2)))

            if draw_moire12 and have_lattice1 and have_lattice2:
                pts_moire_12 = _moire_two(d1, ab1, d2, ab2, moire_exclude_radius_px)
            if draw_moire13 and have_lattice1 and have_lattice3:
                pts_moire_13 = _moire_two(d1, ab1, d3, ab3, moire_exclude_radius_px)
            if draw_moire23 and have_lattice2 and have_lattice3:
                pts_moire_23 = _moire_two(d2, ab2, d3, ab3, moire_exclude_radius_px)
            if draw_moire123 and have_lattice1 and have_lattice2 and have_lattice3:
                pts_moire_123 = _moire_three(d1, ab1, d2, ab2, d3, ab3, moire_exclude_radius_px)
                pair_list = [p for p in (pts_moire_12, pts_moire_13, pts_moire_23) if p is not None and p.size]
                if pts_moire_123 is not None and pts_moire_123.size:
                    if pair_list:
                        pair_all = np.unique(np.vstack(pair_list), axis=0)
                        extra_mask = ~np.isin(_pts_key(pts_moire_123), _pts_key(pair_all))
                        pts_moire_123_extra = pts_moire_123[extra_mask] if np.any(extra_mask) else None
                    else:
                        pts_moire_123_extra = pts_moire_123

        data: dict[str, Any] = {
            "origin_index": ind_origin_i,
            "origin_rc": origin_rc.copy(),
            "max_tile": max_tile_use,
            "lattice1_points_rc": pts1,
            "lattice2_points_rc": pts2,
            "lattice3_points_rc": pts3,
            "moire12_points_rc": pts_moire_12,
            "moire13_points_rc": pts_moire_13,
            "moire23_points_rc": pts_moire_23,
            "moire123_points_rc": pts_moire_123,
            "moire123_extra_points_rc": pts_moire_123_extra,
            "moire_points_rc": pts_moire_123,
        }
        if have_lattice1:
            data.update({"u1_index": ind_u1_i, "v1_index": ind_v1_i, "u1_rc": u1, "v1_rc": v1})
        if have_lattice2:
            data.update({"u2_index": ind_u2_i, "v2_index": ind_v2_i, "u2_rc": u2, "v2_rc": v2})
        if have_lattice3:
            data.update({"u3_index": ind_u3_i, "v3_index": ind_v3_i, "u3_rc": u3, "v3_rc": v3})

        self.lattice_vectors_data = data

        fig, ax = show_2d(im, **kwargs)
        ax0 = ax.flat[0] if hasattr(ax, "flat") else ax
        ax0.scatter([origin_rc[1]], [origin_rc[0]], s=float(s_origin), marker="x", c=[color_origin], linewidths=float(lw_vec), zorder=10)

        def _draw_vec(vec: NDArray[np.float64], color: Any) -> None:
            end = origin_rc + vec
            ax0.plot([origin_rc[1], end[1]], [origin_rc[0], end[0]], color=color, linewidth=float(lw_vec), zorder=9)
            ax0.scatter([end[1]], [end[0]], s=float(s_vec_tip), marker="o", facecolors="none", edgecolors=[color], linewidths=float(lw_vec), zorder=10)

        if have_lattice1 and pts1 is not None and pts1.size:
            _draw_vec(u1, color_lattice1)
            _draw_vec(v1, color_lattice1)
            ax0.scatter(pts1[:, 1], pts1[:, 0], s=float(s_lattice_pts), marker="o", facecolors="none", edgecolors=[color_lattice1], alpha=float(alpha_lattice_pts), zorder=5, label="lattice1")
        if have_lattice2 and pts2 is not None and pts2.size:
            _draw_vec(u2, color_lattice2)
            _draw_vec(v2, color_lattice2)
            ax0.scatter(pts2[:, 1], pts2[:, 0], s=float(s_lattice_pts), marker="o", facecolors="none", edgecolors=[color_lattice2], alpha=float(alpha_lattice_pts), zorder=5, label="lattice2")
        if have_lattice3 and pts3 is not None and pts3.size:
            _draw_vec(u3, color_lattice3)
            _draw_vec(v3, color_lattice3)
            ax0.scatter(pts3[:, 1], pts3[:, 0], s=float(s_lattice_pts), marker="o", facecolors="none", edgecolors=[color_lattice3], alpha=float(alpha_lattice_pts), zorder=5, label="lattice3")

        n12 = n13 = n23 = n123 = n_extra = 0
        if pts_moire_12 is not None and pts_moire_12.size:
            ax0.scatter(pts_moire_12[:, 1], pts_moire_12[:, 0], s=float(s_moire_pair), marker="o", facecolors="none", edgecolors=[color_moire12], alpha=float(alpha_moire_pair), zorder=6, label="moire(1-2)")
            n12 = int(pts_moire_12.shape[0])
        if pts_moire_13 is not None and pts_moire_13.size:
            ax0.scatter(pts_moire_13[:, 1], pts_moire_13[:, 0], s=float(s_moire_pair), marker="o", facecolors="none", edgecolors=[color_moire13], alpha=float(alpha_moire_pair), zorder=6, label="moire(1-3)")
            n13 = int(pts_moire_13.shape[0])
        if pts_moire_23 is not None and pts_moire_23.size:
            ax0.scatter(pts_moire_23[:, 1], pts_moire_23[:, 0], s=float(s_moire_pair), marker="o", facecolors="none", edgecolors=[color_moire23], alpha=float(alpha_moire_pair), zorder=6, label="moire(2-3)")
            n23 = int(pts_moire_23.shape[0])
        if pts_moire_123 is not None and pts_moire_123.size:
            n123 = int(pts_moire_123.shape[0])
            if draw_moire123_all:
                ax0.scatter(pts_moire_123[:, 1], pts_moire_123[:, 0], s=float(s_moire123_all), marker=".", c=[color_moire123_all], alpha=float(alpha_moire123_all), zorder=4, label="moire(1-2-3) all")
        if pts_moire_123_extra is not None and pts_moire_123_extra.size:
            ax0.scatter(pts_moire_123_extra[:, 1], pts_moire_123_extra[:, 0], s=float(s_moire123_extra), marker="x", c=[color_moire123_extra], alpha=float(alpha_moire123_extra), zorder=7, label="moire(1-2-3) extra")
            n_extra = int(pts_moire_123_extra.shape[0])

        handles, labels = ax0.get_legend_handles_labels()
        if labels:
            ax0.legend(loc="upper right", fontsize=9, frameon=True)

        info = f"moire12={n12}, moire13={n13}, moire23={n23}, moire123={n123}, extra={n_extra}"
        ax0.text(
            0.01,
            0.99,
            info,
            transform=ax0.transAxes,
            va="top",
            ha="left",
            fontsize=9,
            bbox=dict(facecolor="white", alpha=0.6, edgecolor="none"),
            zorder=20,
        )
        ax0.figure.canvas.draw_idle()
        return {"data": data, "fig": fig, "ax": ax0} if return_peaks else {}

    def two_lattice_vectors(
        self,
        *,
        ind_origin: int | None = None,
        ind_u1: int | None = None,
        ind_v1: int | None = None,
        ind_u2: int | None = None,
        ind_v2: int | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Backward-compatible wrapper for the two-lattice case."""
        return self.lattice_vectors(
            ind_origin=ind_origin,
            ind_u1=ind_u1,
            ind_v1=ind_v1,
            ind_u2=ind_u2,
            ind_v2=ind_v2,
            ind_u3=None,
            ind_v3=None,
            **kwargs,
        )

    def three_lattice_vectors(
        self,
        *,
        ind_origin: int | None = None,
        ind_u1: int | None = None,
        ind_v1: int | None = None,
        ind_u2: int | None = None,
        ind_v2: int | None = None,
        ind_u3: int | None = None,
        ind_v3: int | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Backward-compatible wrapper for the three-lattice case."""
        return self.lattice_vectors(
            ind_origin=ind_origin,
            ind_u1=ind_u1,
            ind_v1=ind_v1,
            ind_u2=ind_u2,
            ind_v2=ind_v2,
            ind_u3=ind_u3,
            ind_v3=ind_v3,
            **kwargs,
        )

